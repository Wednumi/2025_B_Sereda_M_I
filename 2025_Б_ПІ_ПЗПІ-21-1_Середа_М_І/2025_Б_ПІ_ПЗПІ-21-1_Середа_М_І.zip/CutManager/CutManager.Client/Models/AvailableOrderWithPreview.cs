﻿using CutManager.Shared.Dto.Sheet;

namespace CutManager.Client.Models
{
    public class AvailableOrderWithPreview : AvailableOrderDto
    {
        public string PreviewImage { get; set; } = string.Empty;
        public int PlacedCount { get; set; } = 0;
    }
}
