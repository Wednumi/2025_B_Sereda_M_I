﻿using Blazored.LocalStorage;
using CutManager.Client.Services.Interfaces;
using CutManager.Shared.Dto.Account;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Security
{
    public class AuthenticationService
    {
        private readonly IHttpService _client;
        private readonly AuthStateProvider _authStateProvider;
        private readonly ILocalStorageService _localStorage;

        public AuthenticationService(IHttpService client,
            AuthStateProvider authStateProvider,
            ILocalStorageService localStorage)
        {
            _client = client;
            _authStateProvider = authStateProvider;
            _localStorage = localStorage;
        }

        public async Task<ServiceResponse> LoginAsync(SignInCommandDto credentials)
        {
            var authResult = await _client.SendAsync<SignInResultDto>(HttpMethod.Post, "account/signin", credentials);

            if (authResult.IsSuccess is false)
            {
                return authResult;
            }

            await _localStorage.SetItemAsync("authToken", authResult.Result.Bearer);

            _authStateProvider.NotifyUserAuthentication(authResult.Result.Bearer);

            return ServiceResponseBuilder.Success();
        }

        public async Task<ServiceResponse> SignUpCustomerAsync(CredentialsDto credentials)
        {
            return await _client.SendAsync(HttpMethod.Post, "account/customer/create", credentials);
        }

        public async Task<ServiceResponse> SignUpServiceAdminAsync(CredentialsDto credentials)
        {
            return await _client.SendAsync(HttpMethod.Post, "account/serviceadmin/create", credentials);
        }


        public async Task LogoutAsync()
        {
            await _localStorage.RemoveItemAsync("authToken");
            _authStateProvider.NotifyLogout();
        }
    }
}
