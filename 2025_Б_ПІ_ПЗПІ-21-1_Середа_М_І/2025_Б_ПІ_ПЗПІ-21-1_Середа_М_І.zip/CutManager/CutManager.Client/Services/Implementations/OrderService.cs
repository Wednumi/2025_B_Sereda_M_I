﻿using System.Globalization;
using System.Net.Http.Headers;
using CutManager.Client.Services.Interfaces;
using CutManager.Shared.Dto.Material;
using CutManager.Shared.Dto.Order;
using CutManager.Shared.ServiceResponseHandling;
using Microsoft.AspNetCore.Components.Forms;

namespace CutManager.Client.Services.Implementations
{
    public class OrderService : IOrderService
    {
        private readonly IHttpService _httpService;

        public OrderService(IHttpService httpService)
        {
            _httpService = httpService;
        }

        public async Task<List<OrderDto>> GetAllAsync()
        {
            var response = await _httpService.SendAsync<List<OrderDto>>(HttpMethod.Get, "orders");
            return response.IsSuccess ? response.Result : new List<OrderDto>();
        }

        public async Task<List<MaterialDto>> GetAvailableMaterialsAsync()
        {
            var response = await _httpService.SendAsync<List<MaterialDto>>(HttpMethod.Get, "orders/available-materials");
            return response.IsSuccess ? response.Result : new List<MaterialDto>();
        }

        public async Task<ServiceResponse> CreateOrderAsync(CreateOrderFormDto order, IBrowserFile? file)
        {
            var formData = new MultipartFormDataContent
            {
                { new StringContent(order.MaterialId.ToString()), "MaterialId" },
                { new StringContent(order.Thickness), "Thickness" },
                { new StringContent(order.Quantity.ToString()), "Quantity" }
            };

            if (file != null)
            {
                var stream = file.OpenReadStream(20 * 1024 * 1024); // 20 MB
                var contentType = string.IsNullOrWhiteSpace(file.ContentType)
                    ? "application/octet-stream"
                    : file.ContentType;

                var fileContent = new StreamContent(file.OpenReadStream());
                fileContent.Headers.ContentType = new MediaTypeHeaderValue(contentType);
                formData.Add(fileContent, "File", file.Name);
            }

            return await _httpService.SendAsync(HttpMethod.Post, "orders", formData);
        }

        public async Task<byte[]> DownloadPreviewAsync(Guid orderId)
        {
            var response = await _httpService.SendRawAsync(HttpMethod.Get, $"orders/preview/{orderId}");
            return response;
        }

        public async Task<byte[]> DownloadFileAsync(Guid orderId)
        {
            var response = await _httpService.SendRawAsync(HttpMethod.Get, $"orders/file/{orderId}");
            return response;
        }
    }
}
