﻿using CutManager.Client.Services.Interfaces;
using CutManager.Shared.Dto.CuttingMachine;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Services.Implementations
{
    public class CuttingMachineService : ICuttingMachineService
    {
        private readonly IHttpService _http;

        public CuttingMachineService(IHttpService http)
        {
            _http = http;
        }

        public async Task<List<CuttingMachineDto>> GetAllAsync()
            => (await _http.SendAsync<List<CuttingMachineDto>>(HttpMethod.Get, "cuttingmachines")).Result ?? new List<CuttingMachineDto>();

        public Task<ServiceResponse> CreateOrUpdateAsync(CuttingMachineDto dto)
            => _http.SendAsync(HttpMethod.Post, "cuttingmachines", dto);

        public Task<ServiceResponse> DeleteAsync(Guid id)
            => _http.SendAsync(HttpMethod.Delete, $"cuttingmachines/{id}");

    }
}
