﻿using CutManager.Client.Services.Interfaces;
using CutManager.Shared.Dto.Material;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Services.Implementations
{
    public class MaterialService : IMaterialService
    {
        private readonly IHttpService _http;

        public MaterialService(IHttpService http)
        {
            _http = http;
        }

        public async Task<List<MaterialDto>> GetAllAsync()
        {
            var response = await _http.SendAsync<List<MaterialDto>>(HttpMethod.Get, "materials");
            return response.IsSuccess ? response.Result : new List<MaterialDto>();
        }

        public async Task<ServiceResponse> CreateOrUpdateAsync(MaterialDto dto)
        {
            return await _http.SendAsync(HttpMethod.Post, "materials", dto);
        }

        public async Task<ServiceResponse> DeleteAsync(Guid id)
        {
            return await _http.SendAsync(HttpMethod.Delete, $"materials/{id}");
        }
    }

}
