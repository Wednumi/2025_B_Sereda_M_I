﻿using CutManager.Client.Services.Interfaces;
using CutManager.Shared.Dto.Sheet;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Services.Implementations
{
    public class SheetService : ISheetService
    {
        private readonly IHttpService _httpService;

        public SheetService(IHttpService httpService)
        {
            _httpService = httpService;
        }

        public async Task<List<AvailableOrderDto>> GetAvailableOrdersAsync()
        {
            var response = await _httpService.SendAsync<List<AvailableOrderDto>>(HttpMethod.Get, "sheets/available-orders");
            return response.IsSuccess ? response.Result : new List<AvailableOrderDto>();
        }

        public async Task<byte[]> DownloadPreviewAsync(Guid orderId)
        {
            var response = await _httpService.SendRawAsync(HttpMethod.Get, $"orders/preview/{orderId}");
            return response;
        }

        public async Task<Guid> CreateSheetAsync(CreateSheetCommandDto command)
        {
            var response = await _httpService.SendAsync<Guid>(HttpMethod.Post, "sheets", command);
            return response.IsSuccess ? response.Result : Guid.Empty;
        }

        public async Task<byte[]> DownloadSheetPreviewAsync(Guid sheetId)
        {
            return await _httpService.SendRawAsync(HttpMethod.Get, $"sheets/preview/{sheetId}");
        }

        public async Task<byte[]> DownloadSheetDxfAsync(Guid sheetId)
        {
            return await _httpService.SendRawAsync(HttpMethod.Get, $"sheets/dxf/{sheetId}");
        }

        public async Task<ServiceResponse> SaveSheetLayoutAsync(SaveSheetLayoutCommandDto command)
        {
            return await _httpService.SendAsync(HttpMethod.Post, "sheets/save-layout", command);
        }

        public async Task<List<SheetDto>> GetAllSheetsAsync()
        {
            var response = await _httpService.SendAsync<List<SheetDto>>(HttpMethod.Get, "sheets");
            return response.IsSuccess ? response.Result : new List<SheetDto>();
        }

        public async Task<ServiceResponse> MarkSheetDoneAsync(Guid sheetId)
        {
            return await _httpService.SendAsync(HttpMethod.Post, $"sheets/{sheetId}/done");
        }

        public async Task<ServiceResponse> DeleteSheetAsync(Guid sheetId)
        {
            return await _httpService.SendAsync(HttpMethod.Delete, $"sheets/{sheetId}");
        }
    }
}
