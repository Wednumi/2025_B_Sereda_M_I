﻿using CutManager.Shared.Dto.Sheet;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Services.Interfaces
{
    public interface ISheetService
    {
        Task<List<AvailableOrderDto>> GetAvailableOrdersAsync();
        Task<byte[]> DownloadPreviewAsync(Guid orderId);
        public Task<Guid> CreateSheetAsync(CreateSheetCommandDto command);
        public Task<byte[]> DownloadSheetPreviewAsync(Guid sheetId);
        public Task<byte[]> DownloadSheetDxfAsync(Guid sheetId);
        public Task<ServiceResponse> SaveSheetLayoutAsync(SaveSheetLayoutCommandDto command);
        public Task<List<SheetDto>> GetAllSheetsAsync();
        public Task<ServiceResponse> MarkSheetDoneAsync(Guid sheetId);
        public Task<ServiceResponse> DeleteSheetAsync(Guid sheetId);
    }
}
