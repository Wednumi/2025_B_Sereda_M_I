﻿using CutManager.Shared.Dto.Material;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Services.Interfaces
{
    public interface IMaterialService
    {
        Task<List<MaterialDto>> GetAllAsync();
        Task<ServiceResponse> CreateOrUpdateAsync(MaterialDto dto);
        Task<ServiceResponse> DeleteAsync(Guid id);
    }

}
