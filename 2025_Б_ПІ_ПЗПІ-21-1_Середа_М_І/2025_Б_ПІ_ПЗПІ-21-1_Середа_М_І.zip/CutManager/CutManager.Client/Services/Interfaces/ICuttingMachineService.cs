﻿using CutManager.Shared.Dto.CuttingMachine;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Services.Interfaces
{
    public interface ICuttingMachineService
    {
        Task<List<CuttingMachineDto>> GetAllAsync();
        Task<ServiceResponse> CreateOrUpdateAsync(CuttingMachineDto dto);
        Task<ServiceResponse> DeleteAsync(Guid id);

    }
}
