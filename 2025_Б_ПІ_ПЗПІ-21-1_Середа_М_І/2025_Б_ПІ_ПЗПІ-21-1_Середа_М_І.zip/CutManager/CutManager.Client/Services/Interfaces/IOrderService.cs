﻿using CutManager.Shared.Dto.Material;
using CutManager.Shared.Dto.Order;
using CutManager.Shared.ServiceResponseHandling;
using Microsoft.AspNetCore.Components.Forms;

namespace CutManager.Client.Services.Interfaces
{
    public interface IOrderService
    {
        Task<List<OrderDto>> GetAllAsync();
        Task<List<MaterialDto>> GetAvailableMaterialsAsync();
        Task<ServiceResponse> CreateOrderAsync(CreateOrderFormDto order, IBrowserFile? file);
        Task<byte[]> DownloadPreviewAsync(Guid orderId);
        Task<byte[]> DownloadFileAsync(Guid orderId);
    }
}
