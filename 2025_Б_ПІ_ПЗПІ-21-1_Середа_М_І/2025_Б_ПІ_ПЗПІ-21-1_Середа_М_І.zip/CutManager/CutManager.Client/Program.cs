using Blazored.LocalStorage;
using CutManager.Client;
using CutManager.Client.Security;
using CutManager.Client.Services.Implementations;
using CutManager.Client.Services.Interfaces;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(sp => new HttpClient
{
    BaseAddress = new Uri(builder.Configuration.GetValue<string>("Api"))
});

builder.Services.AddBlazoredLocalStorage();

builder.Services.AddScoped<AuthenticationService>();

builder.Services.AddScoped<IHttpService, HttpService>();
builder.Services.AddScoped<IMaterialService, MaterialService>();
builder.Services.AddScoped<ICuttingMachineService, CuttingMachineService>();
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<ISheetService, SheetService>();

builder.Services.AddAuthorizationCore();
builder.Services.AddScoped<AuthStateProvider>();
builder.Services.AddScoped<AuthenticationStateProvider>(provider
    => provider.GetRequiredService<AuthStateProvider>());

await builder.Build().RunAsync();
