﻿using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Client.Helpers
{
    public static class ErrorMessageHelper
    {
        public static string ErrorMessage(ServiceResponse response)
        {
            return response.Error.ValidationErrors.FirstOrDefault()?.ErrorMessage ?? response.Error.ServiceErrors.FirstOrDefault()?.ErrorMessage;
        }
    }
}
