using netDxf;
using netDxf.Entities;

namespace BlueprintsManager;

public static class DxfEntityTransformer
{
    public static void MoveEntity(EntityObject entity, Vector3 translation)
    {
        switch (entity)
        {
            case Line line:
                line.StartPoint += translation;
                line.EndPoint += translation;
                break;
            case Circle circle:
                circle.Center += translation;
                break;
            case Polyline2D poly:
                for (int i = 0; i < poly.Vertexes.Count; i++)
                {
                    var v = poly.Vertexes[i];
                    poly.Vertexes[i] = new Polyline2DVertex(
                        new Vector2(v.Position.X + translation.X, v.Position.Y + translation.Y),
                        v.Bulge
                    );
                }
                break;
            case Spline spline:
                for (int i = 0; i < spline.ControlPoints.Count(); i++)
                {
                    spline.ControlPoints[i] += translation;
                }
                break;
            case Text text:
                text.Position += translation;
                break;
            case MText mtext:
                mtext.Position += translation;
                break;
        }
    }
}
