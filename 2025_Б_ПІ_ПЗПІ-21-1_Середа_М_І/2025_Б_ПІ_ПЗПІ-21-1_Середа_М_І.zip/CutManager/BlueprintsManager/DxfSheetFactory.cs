using netDxf;
using netDxf.Entities;

namespace BlueprintsManager;

public static class DxfSheetFactory
{
    public static void CreateSheet(double width, double height, string filename)
    {
        if (width <= 0 || height <= 0)
            throw new ArgumentException("Width and height must be positive values.");
        if (string.IsNullOrWhiteSpace(filename))
            throw new ArgumentException("Filename must be provided.");

        var dxf = new DxfDocument();

        dxf.Entities.Add(new Line(new Vector3(0, 0, 0), new Vector3(width, 0, 0)));
        dxf.Entities.Add(new Line(new Vector3(width, 0, 0), new Vector3(width, height, 0)));
        dxf.Entities.Add(new Line(new Vector3(width, height, 0), new Vector3(0, height, 0)));
        dxf.Entities.Add(new Line(new Vector3(0, height, 0), new Vector3(0, 0, 0)));

        dxf.Save(filename);
    }
}