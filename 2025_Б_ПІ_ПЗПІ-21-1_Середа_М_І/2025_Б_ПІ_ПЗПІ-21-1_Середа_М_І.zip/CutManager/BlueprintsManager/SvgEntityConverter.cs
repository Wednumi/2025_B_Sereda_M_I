﻿using netDxf;
using netDxf.Entities;
using System.Globalization;
using System.Text;

namespace BlueprintsManager;

public static class SvgEntityConverter
{
    private const int PolyLineConversionPrecision = 500;

    public static string ConvertToSvg(EntityObject entity, double scale = 1.0, Vector3 translation = default)
    {
        var sb = new StringBuilder();

        switch (entity)
        {
            case Line line:
                sb.AppendLine(string.Format(
                    CultureInfo.InvariantCulture,
                    "<line x1=\"{0}\" y1=\"{1}\" x2=\"{2}\" y2=\"{3}\" stroke=\"black\"/>",
                    (line.StartPoint.X - translation.X) * scale,
                    -((line.StartPoint.Y - translation.Y) * scale),
                    (line.EndPoint.X - translation.X) * scale,
                    -((line.EndPoint.Y - translation.Y) * scale)
                ));
                break;

            case Circle circle:
                sb.AppendLine(string.Format(
                    CultureInfo.InvariantCulture,
                    "<circle cx=\"{0}\" cy=\"{1}\" r=\"{2}\" stroke=\"black\" fill=\"none\"/>",
                    (circle.Center.X - translation.X) * scale,
                    -((circle.Center.Y - translation.Y) * scale),
                    circle.Radius * scale
                ));
                break;

            case Polyline2D poly:
                sb.Append("<polyline points=\"");
                foreach (var v in poly.Vertexes)
                {
                    var x = (v.Position.X - translation.X) * scale;
                    var y = -(v.Position.Y - translation.Y) * scale;
                    sb.AppendFormat(CultureInfo.InvariantCulture, "{0},{1} ", x, y);
                }
                sb.AppendLine("\" fill=\"none\" stroke=\"black\"/>");
                break;

            case Spline spline:
                var convertedPoly = spline.ToPolyline2D(PolyLineConversionPrecision);
                sb.Append("<polyline points=\"");
                foreach (var v in convertedPoly.Vertexes)
                {
                    var x = (v.Position.X - translation.X) * scale;
                    var y = -(v.Position.Y - translation.Y) * scale;
                    sb.AppendFormat(CultureInfo.InvariantCulture, "{0},{1} ", x, y);
                }
                sb.AppendLine("\" fill=\"none\" stroke=\"black\"/>");
                break;
        }

        return sb.ToString();
    }
}
