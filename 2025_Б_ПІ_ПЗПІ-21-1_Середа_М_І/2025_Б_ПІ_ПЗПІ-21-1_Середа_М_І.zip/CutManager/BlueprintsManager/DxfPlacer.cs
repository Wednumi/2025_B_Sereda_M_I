﻿using netDxf.Entities;
using netDxf;

namespace BlueprintsManager;

public class DxfPlacer
{
    public static void Place(DxfDocument targetDoc, DxfDocument insertDoc, Vector3 location)
    {
        var parentHeight = GetDocumentHeight(targetDoc);
        var (childMin, childMax) = DxfBoundsCalculator.GetBounds(insertDoc);
        var moveToOrigin = new Vector3(childMin.X, childMax.Y, 0);
        var flipY = new Vector3(0, parentHeight, 0);
        var finalOffset = new Vector3(location.X, -location.Y, 0);

        foreach (var entity in insertDoc.Entities.All)
        {
            var clone = (EntityObject)entity.Clone();
            var combinedTranslation = flipY - moveToOrigin + finalOffset;
            DxfEntityTransformer.MoveEntity(clone, combinedTranslation);
            targetDoc.Entities.Add(clone);
        }
    }

    private static double GetDocumentHeight(DxfDocument doc)
    {
        var bounds = DxfBoundsCalculator.GetBounds(doc);
        return bounds.max.Y - bounds.min.Y;
    }
}
