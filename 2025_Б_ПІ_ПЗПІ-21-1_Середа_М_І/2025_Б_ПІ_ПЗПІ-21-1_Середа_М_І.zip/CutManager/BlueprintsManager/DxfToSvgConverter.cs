﻿using System.Globalization;
using System.Text;
using netDxf;

namespace BlueprintsManager;

public class DxfToSvgConverter
{
    public static string ConvertFromFile(string targetPath, double scale = 1.0)
    {
        DxfDocument dxfDocument = DxfDocument.Load(targetPath);
        return Convert(dxfDocument, scale);
    }

    public static string Convert(DxfDocument dxf, double scale = 1.0)
    {
        ArgumentNullException.ThrowIfNull(dxf);

        var bounds = DxfBoundsCalculator.GetBounds(dxf);
        var min = bounds.min;
        var max = bounds.max;

        double width = (max.X - min.X) * scale;
        double height = (max.Y - min.Y) * scale;

        var widthString = width.ToString(CultureInfo.InvariantCulture);
        var heightString = height.ToString(CultureInfo.InvariantCulture);

        var translation = new Vector3(min.X, max.Y, 0);
        var sb = new StringBuilder();
        sb.AppendLine($"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{widthString}\" height=\"{heightString}\" viewBox=\"0 0 {widthString} {heightString}\" fill=\"none\" stroke=\"black\">");


        foreach (var entity in dxf.Entities.All)
        {
            sb.Append(SvgEntityConverter.ConvertToSvg(entity, scale, translation));
        }

        sb.AppendLine("</svg>");
        return sb.ToString();
    }
}