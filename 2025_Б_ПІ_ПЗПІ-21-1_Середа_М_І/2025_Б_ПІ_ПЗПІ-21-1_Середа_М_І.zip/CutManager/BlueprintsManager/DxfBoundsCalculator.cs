﻿using netDxf.Entities;
using netDxf;

namespace BlueprintsManager;

public static class DxfBoundsCalculator
{
    public static (Vector3 min, Vector3 max) GetBounds(DxfDocument dxf)
    {
        var min = new Vector3(double.MaxValue, double.MaxValue, 0);
        var max = new Vector3(double.MinValue, double.MinValue, 0);

        foreach (var entity in dxf.Entities.All)
        {
            switch (entity)
            {
                case Line line:
                    min = VectorHelper.MinVector(min, line.StartPoint);
                    max = VectorHelper.MaxVector(max, line.StartPoint);
                    min = VectorHelper.MinVector(min, line.EndPoint);
                    max = VectorHelper.MaxVector(max, line.EndPoint);
                    break;
                case Circle circle:
                    var c = circle.Center;
                    double r = circle.Radius;
                    min = VectorHelper.MinVector(min, new Vector3(c.X - r, c.Y - r, 0));
                    max = VectorHelper.MaxVector(max, new Vector3(c.X + r, c.Y + r, 0));
                    break;
                case Polyline2D poly:
                    foreach (var v in poly.Vertexes)
                    {
                        var p = new Vector3(v.Position.X, v.Position.Y, 0);
                        min = VectorHelper.MinVector(min, p);
                        max = VectorHelper.MaxVector(max, p);
                    }
                    break;
                case Spline spline:
                    foreach (var pt in spline.ControlPoints)
                    {
                        min = VectorHelper.MinVector(min, pt);
                        max = VectorHelper.MaxVector(max, pt);
                    }
                    break;
            }
        }
        return (min, max);
    }
}

