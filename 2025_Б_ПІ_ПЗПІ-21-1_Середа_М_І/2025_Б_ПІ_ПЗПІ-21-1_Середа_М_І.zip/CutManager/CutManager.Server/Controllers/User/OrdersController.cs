using AutoMapper;
using CutManager.Server.Controllers.Base;
using CutManager.Server.Features.Order;
using CutManager.Shared.Dto.Order;
using CutManager.Shared.Helpers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;

namespace CutManager.Server.Controllers.User
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : BaseController
    {
        public OrdersController(IMediator mediator, IMapper mapper) : base(mapper, mediator) { }

        [HttpPost]
        [Authorize(Roles = Roles.Customer)]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> Create([FromForm] CreateOrderFormDto request, CancellationToken cancellationToken)
        {
            var fileResponse = await _mediator.Send(new SaveOrderFileCommand { File = request.File }, cancellationToken);
            if (!fileResponse.IsSuccess)
                return ConvertFromServiceResponse(fileResponse.MapErrorResult());

            var command = new CreateOrderCommand
            {
                MaterialId = request.MaterialId,
                Thickness = float.Parse(request.Thickness, CultureInfo.InvariantCulture),
                Quantity = request.Quantity,
                DxfFileName = fileResponse.Result,
            };

            var result = await _mediator.Send(command, cancellationToken);
            return ConvertFromServiceResponse(result);
        }

        [HttpGet]
        [Authorize(Roles = Roles.Customer)]
        public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new GetUserOrdersQuery(), cancellationToken));

        [Authorize(Roles = Roles.ServiceAdmin + "," + Roles.Customer)]
        [HttpGet("file/{orderId}")]
        public async Task<IActionResult> DownloadFile(Guid orderId, CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new DownloadOrderFileCommand
            {
                OrderId = orderId
            }, cancellationToken);

            if (!result.IsSuccess || result.Result == null)
                return NotFound();

            return result.Result;
        }

        [Authorize(Roles = Roles.ServiceAdmin + "," + Roles.Customer)]
        [HttpGet("preview/{orderId}")]
        public async Task<IActionResult> DownloadPreview(Guid orderId, CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new DownloadOrderPreviewCommand
            {
                OrderId = orderId
            }, cancellationToken);

            if (!result.IsSuccess || result.Result == null)
                return NotFound();

            return result.Result;
        }

        [Authorize(Roles = Roles.Customer)]
        [HttpGet("available-materials")]
        public async Task<IActionResult> GetAvailableMaterials(CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new GetAvailableMaterialsQuery(), cancellationToken);
            return ConvertFromServiceResponse(result);
        }

    }
}
