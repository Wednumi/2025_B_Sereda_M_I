﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using CutManager.Server.Controllers.Base;
using CutManager.Server.Features.Account;
using CutManager.Shared.Errors.Base;
using CutManager.Shared.Dto.Account;

namespace CutManager.Server.Controllers.User
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : BaseController
    {
        public AccountController(IMediator mediator, IMapper mapper)
            : base(mapper, mediator)
        {
        }

        [HttpPost("customer/create")]
        [ProducesResponseType(200)]
        [ProducesResponseType(typeof(Error), 400)]
        public async Task<IActionResult> SignUpCustomer(
            CreateCustomerCommand request,
            CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(request, cancellationToken);
            return ConvertFromServiceResponse(result);
        }

        [HttpPost("serviceadmin/create")]
        [ProducesResponseType(200)]
        [ProducesResponseType(typeof(Error), 400)]
        public async Task<IActionResult> SignUpServiceAdmin(
            CreateServiceAdminCommand request,
            CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(request, cancellationToken);
            return ConvertFromServiceResponse(result);
        }


        [HttpPost("signin")]
        [ProducesResponseType(typeof(SignInResultDto), 200)]
        [ProducesResponseType(typeof(Error), 400)]
        public async Task<IActionResult> SignInCustomer(
            SignInCommand request,
            CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(request, cancellationToken);
            return ConvertFromServiceResponse(result);
        }
    }
}
