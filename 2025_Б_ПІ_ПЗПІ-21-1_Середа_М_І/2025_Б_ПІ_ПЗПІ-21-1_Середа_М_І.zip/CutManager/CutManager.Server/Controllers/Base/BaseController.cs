﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Server.Controllers.Base
{
    public abstract class BaseController : ControllerBase
    {
        private readonly IMapper _mapper;

        protected readonly IMediator _mediator;

        public BaseController(IMapper mapper, IMediator mediator)
        {
            _mapper = mapper;
            _mediator = mediator;
        }

        protected IActionResult ConvertFromServiceResponse(ServiceResponse serviceResponse)
        {
            if (serviceResponse.IsSuccess)
            {
                return Ok();
            }
            return BadRequest(serviceResponse.Error);
        }

        protected IActionResult ConvertFromServiceResponse<T>(ServiceResponse<T> serviceResponse)
        {
            if (serviceResponse.IsSuccess)
            {
                return Ok(serviceResponse.Result);
            }
            return BadRequest(serviceResponse.Error);
        }
    }
}
