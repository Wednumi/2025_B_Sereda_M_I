﻿using AutoMapper;
using CutManager.Server.Controllers.Base;
using CutManager.Server.Features.Sheets;
using CutManager.Shared.Helpers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CutManager.Server.Controllers.Service
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = Roles.ServiceAdmin)]
    public class SheetsController : BaseController
    {
        public SheetsController(IMediator mediator, IMapper mapper) : base(mapper, mediator) { }

        [HttpPost]
        public async Task<IActionResult> Create(CreateSheetCommand command, CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(command, cancellationToken));

        [HttpPost("save-layout")]
        public async Task<IActionResult> SaveLayout(SaveSheetLayoutCommand command, CancellationToken cancellationToken)
        {
            var response = await _mediator.Send(command, cancellationToken);
            return ConvertFromServiceResponse(response);
        }

        [HttpGet("available-orders")]
        public async Task<IActionResult> GetAvailableOrders(CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new GetAvailableOrdersQuery(), cancellationToken));

        [HttpGet("preview/{sheetId}")]
        public async Task<IActionResult> DownloadSheetPreview(Guid sheetId, CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new DownloadSheetPreviewCommand { SheetId = sheetId }, cancellationToken);
            if (!result.IsSuccess || result.Result == null)
                return NotFound();
            return result.Result;
        }

        [HttpGet("dxf/{sheetId}")]
        public async Task<IActionResult> DownloadSheetDxf(Guid sheetId, CancellationToken cancellationToken)
        {
            var result = await _mediator.Send(new DownloadSheetDxfCommand { SheetId = sheetId }, cancellationToken);
            if (!result.IsSuccess || result.Result == null)
                return NotFound();
            return result.Result;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new GetAllSheetsQuery(), cancellationToken));

        [HttpPost("{id}/done")]
        public async Task<IActionResult> MarkDone(Guid id, CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new MarkSheetDoneCommand { SheetId = id }, cancellationToken));

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new DeleteSheetCommand { SheetId = id }, cancellationToken));

    }
}
