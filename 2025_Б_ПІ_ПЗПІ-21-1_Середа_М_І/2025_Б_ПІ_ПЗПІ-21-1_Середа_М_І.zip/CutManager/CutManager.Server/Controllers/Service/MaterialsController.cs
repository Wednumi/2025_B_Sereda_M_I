﻿using AutoMapper;
using CutManager.Server.Controllers.Base;
using CutManager.Server.Features.Materials;
using CutManager.Shared.Helpers;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CutManager.Server.Controllers.Service
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = Roles.ServiceAdmin)]
    public class MaterialsController : BaseController
    {
        public MaterialsController(IMediator mediator, IMapper mapper)
            : base(mapper, mediator)
        {
        }

        [HttpGet]
        public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new GetAllMaterialsQuery(), cancellationToken));

        [HttpPost]
        public async Task<IActionResult> CreateOrUpdate(CreateOrUpdateMaterialCommand command, CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(command, cancellationToken));

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
            => ConvertFromServiceResponse(await _mediator.Send(new DeleteMaterialCommand { Id = id }, cancellationToken));
    }
}
