﻿using System.Security.Claims;

namespace CutManager.Server.Extensions
{
    public static class HttpContextExtensions
    {
        public static Guid GetUserId(this IHttpContextAccessor contextAccessor)
        {
            return contextAccessor.HttpContext.GetUserId();
        }

        public static Guid GetUserId(this HttpContext? context)
        {
            var identityName = context?.User?.Claims?.Single(c => c.Type == ClaimTypes.NameIdentifier).Value;

            var isValid = Guid.TryParse(identityName, out Guid parsedUserId);

            if (isValid && parsedUserId == Guid.Empty)
            {
                isValid = !isValid;
            }

            return parsedUserId;
        }

        public static List<string> GetUserRoles(this IHttpContextAccessor httpContextAccessor)
        {
            var user = httpContextAccessor.HttpContext?.User;

            if (user == null || !user.Identity?.IsAuthenticated == true)
                return new List<string>();

            var roles = user.Claims
                .Where(c => c.Type == ClaimTypes.Role)
                .Select(c => c.Value)
                .ToList();

            return roles;
        }
    }
}
