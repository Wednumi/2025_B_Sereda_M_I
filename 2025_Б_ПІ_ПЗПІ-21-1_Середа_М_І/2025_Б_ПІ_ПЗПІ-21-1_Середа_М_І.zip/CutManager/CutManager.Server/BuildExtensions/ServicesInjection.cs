﻿using CutManager.Server.Mediator.Pipeline;
using CutManager.Server.Services.Implementations;
using CutManager.Server.Services.Interfaces;
using MediatR;

namespace CutManager.Server.BuildExtensions
{
    internal static class ServicesInjection
    {
        internal static void AddServices(this IServiceCollection services)
        {
            services.AddTransient<ITokenGenerator, JwtTokenGenerator>();
            services.AddTransient<IValidationService, ValidationService>();
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));
            services.AddTransient<IFileConverterService, DxfToSvgFileConverter>();
            services.AddTransient<ISheetDxfAssemblerService, SheetDxfAssemblerService>();
            services.AddScoped<IOrderStatusService, OrderStatusService>();
        }
    }
}
