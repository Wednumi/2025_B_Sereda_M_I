﻿using CutManager.Server.Features.Account;
using CutManager.Server.Features.CuttingMachine;
using CutManager.Server.Features.Materials;
using CutManager.Server.Features.Order;
using CutManager.Shared.Validators.Account;
using CutManager.Shared.Validators.Admin;
using CutManager.Shared.Validators.Customer;
using FluentValidation;

namespace CutManager.Server.BuildExtensions
{
    internal static class ValidatorsInjection
    {
        internal static void AddValidators(this IServiceCollection services)
        {
            services.AddTransient<IValidator<CreateIdentityUserCommand>, CreateIdentityUserCommandValidator>();
            services.AddTransient<IValidator<CreateOrUpdateMaterialCommand>, CreateOrUpdateMaterialValidator>();
            services.AddTransient<IValidator<CreateOrUpdateCuttingMachineCommand>, CreateOrUpdateCuttingMachineValidator>();
            services.AddTransient<IValidator<CreateOrderCommand>, CreateOrderValidator>();
        }
    }
}
