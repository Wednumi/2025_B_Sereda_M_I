﻿using CutManager.Shared.ServiceResponseHandling;

namespace CutManager.Server.Services.Interfaces
{
    public interface IValidationService
    {
        public Task<ServiceResponse> ValidateAsync<T>(T item);
    }
}
