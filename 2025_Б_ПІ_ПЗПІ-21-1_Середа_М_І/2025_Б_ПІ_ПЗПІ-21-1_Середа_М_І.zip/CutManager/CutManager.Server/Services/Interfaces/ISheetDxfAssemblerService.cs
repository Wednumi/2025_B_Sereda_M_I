﻿namespace CutManager.Server.Services.Interfaces
{
    public interface ISheetDxfAssemblerService
    {
        void LoadBaseSheet(string dxfFilePath);
        void InsertOrderDxf(string orderDxfPath, float translateX, float translateY);
        void SaveUpdatedSheet(string outputDxfPath);
    }
}
