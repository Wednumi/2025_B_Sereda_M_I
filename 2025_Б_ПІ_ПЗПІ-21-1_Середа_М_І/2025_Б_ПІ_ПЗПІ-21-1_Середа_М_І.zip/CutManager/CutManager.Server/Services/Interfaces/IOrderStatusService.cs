﻿using CutManager.Db.Models;
using CutManager.Shared.Helpers;

namespace CutManager.Server.Services.Interfaces
{
    public interface IOrderStatusService
    {
        Task UpdateStatusesAsync(IEnumerable<SheetOrderPlacement> placements, OrderStatus newStatus, CancellationToken cancellationToken);
    }
}
