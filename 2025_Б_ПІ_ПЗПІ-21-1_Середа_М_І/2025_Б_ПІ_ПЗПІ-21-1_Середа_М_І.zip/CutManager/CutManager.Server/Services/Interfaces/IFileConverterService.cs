﻿namespace CutManager.Server.Services.Interfaces
{
    public interface IFileConverterService
    {
        Task<string> ConvertDxfToSvgAsync(string dxfFilePath, CancellationToken cancellationToken);
    }

}
