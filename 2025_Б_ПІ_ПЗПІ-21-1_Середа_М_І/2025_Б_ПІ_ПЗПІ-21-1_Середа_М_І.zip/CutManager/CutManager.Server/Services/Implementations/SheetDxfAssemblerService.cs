﻿using BlueprintsManager;
using CutManager.Server.Services.Interfaces;
using netDxf;

namespace CutManager.Server.Services.Implementations
{
    public class SheetDxfAssemblerService : ISheetDxfAssemblerService
    {
        private DxfDocument? _sheetDxf;

        public void InsertOrderDxf(string orderDxfPath, float translateX, float translateY)
        {
            if(_sheetDxf is null)
            {
                return;
            }

            var orderDxf = DxfDocument.Load(orderDxfPath);
            var translation = new Vector3(translateX / DxfToSvgFileConverter.DxfToSvgScale, translateY / DxfToSvgFileConverter.DxfToSvgScale, 0);
            DxfPlacer.Place(_sheetDxf, orderDxf, translation);
        }

        public void LoadBaseSheet(string dxfFilePath)
        {
            _sheetDxf = DxfDocument.Load(dxfFilePath);
        }

        public void SaveUpdatedSheet(string outputDxfPath)
        {
            _sheetDxf?.Save(outputDxfPath);
        }
    }
}
