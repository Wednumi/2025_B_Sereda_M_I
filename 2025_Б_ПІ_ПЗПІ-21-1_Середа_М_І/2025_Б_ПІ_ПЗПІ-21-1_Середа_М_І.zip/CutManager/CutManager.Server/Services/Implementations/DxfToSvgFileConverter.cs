using BlueprintsManager;
using CutManager.Server.Services.Interfaces;

namespace CutManager.Server.Services.Implementations
{
    public class DxfToSvgFileConverter : IFileConverterService
    {
        public static readonly int DxfToSvgScale = 3;

        public Task<string> ConvertDxfToSvgAsync(string dxfFilePath, CancellationToken cancellationToken)
        {
            var svgFileName = Path.ChangeExtension(Path.GetFileName(dxfFilePath), ".svg");
            var uploadsDir = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
            var svgFullPath = Path.Combine(uploadsDir, svgFileName);
            var dxfFilePathFull = Path.Combine(uploadsDir, dxfFilePath);

            var svgContent = DxfToSvgConverter.ConvertFromFile(dxfFilePathFull, DxfToSvgScale);

            Directory.CreateDirectory(uploadsDir);

            File.WriteAllText(svgFullPath, svgContent);

            return Task.FromResult(svgFileName);
        }
    }
}
