﻿using CutManager.Server.Services.Interfaces;

namespace CutManager.Server.Services.Implementations
{
    public class StubFileConverterService : IFileConverterService
    {
        public Task<string> ConvertDxfToSvgAsync(string dxfFilePath, CancellationToken cancellationToken)
        {
            // Generate fake SVG file name (same name, .svg extension)
            var svgFileName = Path.ChangeExtension(Path.GetFileName(dxfFilePath), ".svg");
            var uploadsDir = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
            var svgFullPath = Path.Combine(uploadsDir, svgFileName);

            // Create SVG content: circle + text “stub”
            var svgContent = @"
<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'>
    <circle cx='100' cy='100' r='80' fill='lightgray' stroke='black' stroke-width='2'/>
    <text x='100' y='110' font-family='Arial' font-size='20' fill='black' text-anchor='middle'>stub</text>
</svg>";

            // Ensure directory exists
            Directory.CreateDirectory(uploadsDir);

            // Write SVG to file
            File.WriteAllText(svgFullPath, svgContent);

            return Task.FromResult(svgFileName);
        }
    }
}
