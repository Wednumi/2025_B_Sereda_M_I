﻿using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Server.Services.Interfaces;
using CutManager.Shared.Helpers;
using Microsoft.EntityFrameworkCore;

namespace CutManager.Server.Services.Implementations
{
    public class OrderStatusService : IOrderStatusService
    {
        private readonly ApplicationDbContext _context;

        public OrderStatusService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task UpdateStatusesAsync(IEnumerable<SheetOrderPlacement> placements, OrderStatus newStatus, CancellationToken cancellationToken)
        {
            var orderIds = placements.Select(p => p.OrderId).Distinct().ToList();

            var orders = await _context.Orders
                .Where(o => orderIds.Contains(o.Id))
                .ToListAsync(cancellationToken);

            foreach (var order in orders)
            {
                if (order.CurrentStatus != newStatus)
                {
                    order.CurrentStatus = newStatus;
                    order.StatusHistory.Add(new OrderStatusHistory
                    {
                        OrderId = order.Id,
                        Status = newStatus,
                        ChangedAt = DateTime.UtcNow
                    });
                }
            }

            await _context.SaveChangesAsync(cancellationToken);
        }
    }
}
