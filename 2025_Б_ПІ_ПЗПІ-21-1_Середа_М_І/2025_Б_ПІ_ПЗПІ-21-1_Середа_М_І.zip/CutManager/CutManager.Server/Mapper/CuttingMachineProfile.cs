﻿using AutoMapper;
using CutManager.Db.Models;
using CutManager.Shared.Dto.CuttingMachine;

namespace CutManager.Server.Mapper
{
    public class CuttingMachineProfile : Profile
    {
        public CuttingMachineProfile()
        {
            CreateMap<CuttingMachine, CuttingMachineDto>()
                .ForMember(dest => dest.SupportedMaterialIds, opt => opt.MapFrom(src => src.CuttingMachineMaterials.Select(cmm => cmm.MaterialId)));

            CreateMap<CuttingMachineDto, CuttingMachine>()
                .ForMember(dest => dest.CuttingMachineMaterials, opt => opt.Ignore());
        }
    }
}

