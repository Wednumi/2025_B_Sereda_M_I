﻿using AutoMapper;
using CutManager.Db.Models;
using CutManager.Shared.Dto.Material;

namespace CutManager.Server.Mapper
{
    public class MaterialProfile : Profile
    {
        public MaterialProfile()
        {
            CreateMap<MaterialDto, Material>()
                .ForMember(dest => dest.Thicknesses, opt => opt.Ignore()); // handled in command

            CreateMap<Material, MaterialDto>()
                .ForMember(dest => dest.Thicknesses, opt => opt.MapFrom(src =>
                    src.Thicknesses.Select(t => t.Thickness)));
        }
    }
}
