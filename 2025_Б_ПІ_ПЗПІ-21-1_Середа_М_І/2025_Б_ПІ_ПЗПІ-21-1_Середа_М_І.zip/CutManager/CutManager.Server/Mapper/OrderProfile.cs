﻿using AutoMapper;
using CutManager.Db.Models;
using CutManager.Shared.Dto.Order;

namespace CutManager.Server.Mapper
{
    public class OrderProfile : Profile
    {
        public OrderProfile()
        {
            CreateMap<Order, OrderDto>()
                .ForMember(dest => dest.MaterialName, opt => opt.MapFrom(src => src.Material.Name));

            CreateMap<OrderStatusHistory, OrderStatusHistoryDto>();
        }
    }

}
