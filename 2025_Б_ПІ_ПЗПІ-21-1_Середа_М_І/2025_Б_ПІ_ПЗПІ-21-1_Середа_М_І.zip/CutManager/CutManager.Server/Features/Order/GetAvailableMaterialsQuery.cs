﻿using AutoMapper;
using CutManager.Db;
using CutManager.Shared.Dto.Material;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CutManager.Server.Features.Order
{
    public class GetAvailableMaterialsQuery : IRequest<ServiceResponse<List<MaterialDto>>>
    {
        public class Handler : HandlerBase<GetAvailableMaterialsQuery, List<MaterialDto>>
        {
            private readonly ApplicationDbContext _context;
            private readonly IMapper _mapper;

            public Handler(ApplicationDbContext context, IMapper mapper, ILogger<Handler> logger)
                : base(logger)
            {
                _context = context;
                _mapper = mapper;
            }

            protected override async Task<ServiceResponse<List<MaterialDto>>> PerformLogicAsync(
                GetAvailableMaterialsQuery request,
                CancellationToken cancellationToken)
            {
                var materials = await _context.Materials
                    .Where(m => m.CuttingMachineMaterials.Any())
                    .Include(m => m.Thicknesses)
                    .ToListAsync(cancellationToken);

                var materialDtos = _mapper.Map<List<MaterialDto>>(materials);

                return ServiceResponseBuilder.Success(materialDtos);
            }
        }
    }
}
