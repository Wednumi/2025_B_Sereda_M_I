﻿using CutManager.Shared.ServiceResponseHandling;
using MediatR;

namespace CutManager.Server.Features.Order
{
    public class SaveOrderFileCommand : IRequest<ServiceResponse<string>>
    {
        public IFormFile File { get; set; } = null!;

        public class Handler : IRequestHandler<SaveOrderFileCommand, ServiceResponse<string>>
        {
            public async Task<ServiceResponse<string>> Handle(SaveOrderFileCommand request, CancellationToken cancellationToken)
            {
                var uploadsDir = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
                if (!Directory.Exists(uploadsDir))
                    Directory.CreateDirectory(uploadsDir);

                var fileName = Guid.NewGuid() + Path.GetExtension(request.File.FileName);
                var filePath = Path.Combine(uploadsDir, fileName);

                using var stream = new FileStream(filePath, FileMode.Create);
                await request.File.CopyToAsync(stream, cancellationToken);

                return ServiceResponseBuilder.Success(fileName);
            }
        }
    }
}
