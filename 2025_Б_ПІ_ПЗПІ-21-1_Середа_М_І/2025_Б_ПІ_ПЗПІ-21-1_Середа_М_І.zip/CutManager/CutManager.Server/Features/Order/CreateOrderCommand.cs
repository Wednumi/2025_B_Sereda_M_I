﻿using AutoMapper;
using CutManager.Db.Models;
using CutManager.Db;
using CutManager.Server.Features.Base;
using CutManager.Shared.Dto.Order;
using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.Helpers;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using CutManager.Server.Extensions;
using Microsoft.EntityFrameworkCore;
using CutManager.Server.Services.Interfaces;

namespace CutManager.Server.Features.Order
{
    public class CreateOrderCommand : CreateOrderCommandDto, IRequest<ServiceResponse>
    {
        public class Handler : HandlerBase<CreateOrderCommand>
        {
            private readonly ApplicationDbContext _context;
            private readonly IFileConverterService _fileConverter;
            private readonly IMapper _mapper;
            private readonly IHttpContextAccessor _httpContext;

            public Handler(ApplicationDbContext context, IFileConverterService fileConverter, IMapper mapper, ILogger<Handler> logger, IHttpContextAccessor httpContext)
                : base(logger)
            {
                _context = context;
                _fileConverter = fileConverter;
                _mapper = mapper;
                _httpContext = httpContext;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(CreateOrderCommand request, CancellationToken cancellationToken)
            {
                var userId = _httpContext.GetUserId();
                var customer = await GetCustomerAsync(userId, cancellationToken);
                if (customer == null)
                    return ServiceResponseBuilder.Failure(ServerError.NotFound);

                var material = await GetMaterialWithDetailsAsync(request.MaterialId, cancellationToken);
                if (material == null)
                    return ServiceResponseBuilder.Failure(ServerError.NotFound);

                var thicknessCheck = CheckMaterialThickness(material, request.Thickness);
                if (!thicknessCheck.IsSuccess)
                    return thicknessCheck;

                var machineCheck = CheckMaterialSupportedByMachine(material);
                if (!machineCheck.IsSuccess)
                    return machineCheck;

                var svgFileName = await _fileConverter.ConvertDxfToSvgAsync(request.DxfFileName, cancellationToken);

                var order = new CutManager.Db.Models.Order
                {
                    CustomerId = customer.Id,
                    MaterialId = request.MaterialId,
                    Thickness = request.Thickness,
                    Quantity = request.Quantity,
                    DxfFilePath = request.DxfFileName,
                    SvgPreviewPath = svgFileName,
                    CurrentStatus = OrderStatus.Created,
                    CreatedAt = DateTime.UtcNow,
                    StatusHistory = new List<OrderStatusHistory>
                    {
                        new OrderStatusHistory
                        {
                            Status = OrderStatus.Created,
                            ChangedAt = DateTime.UtcNow
                        }
                    }
                };

                _context.Orders.Add(order);
                await _context.SaveChangesAsync(cancellationToken);

                return ServiceResponseBuilder.Success();
            }


            private async Task<Customer?> GetCustomerAsync(Guid userId, CancellationToken cancellationToken)
            {
                return await _context.Customers.FirstOrDefaultAsync(c => c.Id == userId, cancellationToken);
            }

            private async Task<Material?> GetMaterialWithDetailsAsync(Guid materialId, CancellationToken cancellationToken)
            {
                return await _context.Materials
                    .Include(m => m.Thicknesses)
                    .Include(m => m.CuttingMachineMaterials)
                    .FirstOrDefaultAsync(m => m.Id == materialId, cancellationToken);
            }

            private ServiceResponse CheckMaterialThickness(Material material, float requestedThickness)
            {
                var hasThickness = material.Thicknesses.Any(t => t.Thickness == requestedThickness);
                return hasThickness
                    ? ServiceResponseBuilder.Success()
                    : ServiceResponseBuilder.Failure(OrderError.InvalidMaterialThickness);
            }

            private ServiceResponse CheckMaterialSupportedByMachine(Material material)
            {
                var isHandled = material.CuttingMachineMaterials.Any();
                return isHandled
                    ? ServiceResponseBuilder.Success()
                    : ServiceResponseBuilder.Failure(OrderError.MaterialNotSupportedByMachine);
            }

        }
    }
}
