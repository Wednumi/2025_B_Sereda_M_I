﻿using AutoMapper;
using CutManager.Db;
using CutManager.Server.Extensions;
using CutManager.Shared.Dto.Order;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CutManager.Server.Features.Order
{
    public class GetUserOrdersQuery : IRequest<ServiceResponse<List<OrderDto>>>
    {
        public class Handler : IRequestHandler<GetUserOrdersQuery, ServiceResponse<List<OrderDto>>>
        {
            private readonly ApplicationDbContext _context;
            private readonly IMapper _mapper;
            private readonly IHttpContextAccessor _httpContext;

            public Handler(ApplicationDbContext context, IMapper mapper, IHttpContextAccessor httpContext)
            {
                _context = context;
                _mapper = mapper;
                _httpContext = httpContext;
            }

            public async Task<ServiceResponse<List<OrderDto>>> Handle(GetUserOrdersQuery request, CancellationToken cancellationToken)
            {
                var userId = _httpContext.HttpContext!.GetUserId();
                var orders = await _context.Orders
                    .Include(o => o.Material)
                    .Include(o => o.StatusHistory)
                    .Where(o => o.CustomerId == userId)
                    .ToListAsync(cancellationToken);

                var result = _mapper.Map<List<OrderDto>>(orders);
                foreach (var order in result)
                {
                    var history = orders.First(o => o.Id == order.Id).StatusHistory;
                    order.StatusHistory = history
                        .OrderBy(h => h.ChangedAt)
                        .Select(h => new OrderStatusHistoryDto
                        {
                            Status = h.Status.ToString(),
                            ChangedAt = h.ChangedAt
                        }).ToList();
                }

                return ServiceResponseBuilder.Success(result);
            }
        }
    }

}
