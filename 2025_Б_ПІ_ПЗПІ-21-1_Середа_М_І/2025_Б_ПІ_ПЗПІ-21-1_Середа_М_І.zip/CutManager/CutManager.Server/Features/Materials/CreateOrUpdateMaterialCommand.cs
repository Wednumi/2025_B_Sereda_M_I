﻿using AutoMapper;
using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Shared.Dto.Material;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using Microsoft.EntityFrameworkCore;
using MediatR;
using CutManager.Shared.Errors.ServiceErrors;

namespace CutManager.Server.Features.Materials
{
    public class CreateOrUpdateMaterialCommand : MaterialDto, IRequest<ServiceResponse>
    {
        public class CreateOrUpdateMaterialCommandHandler : HandlerBase<CreateOrUpdateMaterialCommand>
        {
            private readonly ApplicationDbContext _context;
            private readonly IMapper _mapper;

            public CreateOrUpdateMaterialCommandHandler(ApplicationDbContext context, IMapper mapper, ILogger<CreateOrUpdateMaterialCommandHandler> logger)
                : base(logger)
            {
                _context = context;
                _mapper = mapper;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(CreateOrUpdateMaterialCommand request, CancellationToken cancellationToken)
            {
                Material? material;

                if (request.Id.HasValue)
                {
                    material = await _context.Materials
                        .Include(m => m.Thicknesses)
                        .FirstOrDefaultAsync(m => m.Id == request.Id.Value, cancellationToken);

                    if (material == null)
                        return ServiceResponseBuilder.Failure(ServerError.NotFound);

                    _mapper.Map(request, material);
                    material.Thicknesses = request.Thicknesses.Select(t => new MaterialThickness { Thickness = t }).ToList();
                }
                else
                {
                    material = _mapper.Map<Material>(request);
                    material.Thicknesses = request.Thicknesses.Select(t => new MaterialThickness { Thickness = t }).ToList();
                    _context.Materials.Add(material);
                }

                await _context.SaveChangesAsync(cancellationToken);
                return ServiceResponseBuilder.Success();
            }
        }
    }
}
