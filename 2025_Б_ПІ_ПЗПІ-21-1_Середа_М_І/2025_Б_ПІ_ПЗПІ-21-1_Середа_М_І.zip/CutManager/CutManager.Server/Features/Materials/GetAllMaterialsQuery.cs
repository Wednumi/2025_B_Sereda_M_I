﻿using AutoMapper;
using CutManager.Db;
using CutManager.Shared.Dto.Material;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;

public class GetAllMaterialsQuery : IRequest<ServiceResponse<List<MaterialDto>>>
{
    public class Handler : IRequestHandler<GetAllMaterialsQuery, ServiceResponse<List<MaterialDto>>>
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;

        public Handler(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<ServiceResponse<List<MaterialDto>>> Handle(GetAllMaterialsQuery request, CancellationToken cancellationToken)
        {
            var materials = await _context.Materials
                .Include(m => m.Thicknesses)
                .ToListAsync(cancellationToken);

            var dtoList = _mapper.Map<List<MaterialDto>>(materials);
            return ServiceResponseBuilder.Success(dtoList);
        }
    }
}
