﻿using CutManager.Db;
using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;

public class DeleteMaterialCommand : IRequest<ServiceResponse>
{
    public Guid Id { get; set; }

    public class Handler : IRequestHandler<DeleteMaterialCommand, ServiceResponse>
    {
        private readonly ApplicationDbContext _context;

        public Handler(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<ServiceResponse> Handle(DeleteMaterialCommand request, CancellationToken cancellationToken)
        {
            var material = await _context.Materials
                .Include(m => m.Thicknesses)
                .FirstOrDefaultAsync(m => m.Id == request.Id, cancellationToken);

            if (material == null)
                return ServiceResponseBuilder.Failure(ServerError.NotFound);

            _context.Materials.Remove(material);
            await _context.SaveChangesAsync(cancellationToken);

            return ServiceResponseBuilder.Success();
        }
    }
}
