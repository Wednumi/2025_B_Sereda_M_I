﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using CutManager.Server.Models.Account;
using CutManager.Shared.Dto.Account;
using CutManager.Shared.Errors.Base;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;

namespace CutManager.Server.Features.Account
{
    public class CreateIdentityUserCommand : CredentialsDto, IRequest<ServiceResponse<CreateIdentityUserResult>>
    {
        public string Role { get; set; }

        public class CreateIdentityUserCommandHandler
            : HandlerBase<CreateIdentityUserCommand, CreateIdentityUserResult>
        {
            private readonly UserManager<IdentityUser> _userManager;
            private readonly RoleManager<IdentityRole> _roleManager;

            public CreateIdentityUserCommandHandler(UserManager<IdentityUser> userManager,
                RoleManager<IdentityRole> roleManager,
                ILogger<CreateIdentityUserCommandHandler> logger)
                :base(logger)
            {
                _userManager = userManager;
                _roleManager = roleManager;
            }

            protected override async Task<ServiceResponse<CreateIdentityUserResult>> PerformLogicAsync(
                CreateIdentityUserCommand request,
                CancellationToken cancellationToken)
            {
                var identityUser = new IdentityUser()
                {
                    Email = request.Email,
                    UserName = request.Email
                };

                var createResult = await _userManager.CreateAsync(identityUser, request.Password);
                if (createResult.Succeeded is false)
                {
                    var errors = createResult.Errors.Select(e => new ServiceError()
                    { Header = "UserError", ErrorMessage = e.Description }).ToList();
                    return ServiceResponseBuilder.Failure<CreateIdentityUserResult>(errors);
                }

                await AssureRoleCreatedAsync(request.Role);
                await _userManager.AddToRoleAsync(identityUser, request.Role);

                return ServiceResponseBuilder.Success(new CreateIdentityUserResult() { IdentityUser = identityUser });
            }

            private async Task AssureRoleCreatedAsync(string role)
            {
                if (await _roleManager.RoleExistsAsync(role))
                {
                    return;
                }
                await _roleManager.CreateAsync(new IdentityRole(role));
            }
        }
    }
}
