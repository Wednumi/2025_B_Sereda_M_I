﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using CutManager.Server.Features.Base;
using CutManager.Server.Services.Interfaces;
using CutManager.Shared.Dto.Account;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Shared.Errors.ServiceErrors;

namespace CutManager.Server.Features.Account
{
    public class SignInCommand : CredentialsDto, IRequest<ServiceResponse<SignInResultDto>>
    {
        public class SignInCommandHandler : HandlerBase<SignInCommand, SignInResultDto>
        {
            private readonly UserManager<IdentityUser> _userManager;
            private readonly ITokenGenerator _tokenGenerator;

            public SignInCommandHandler(UserManager<IdentityUser> userManager,
                ITokenGenerator tokenGenerator,
                ILogger<SignInCommandHandler> logger)
                : base(logger)
            {
                _userManager = userManager;
                _tokenGenerator = tokenGenerator;
            }

            protected override async Task<ServiceResponse<SignInResultDto>> PerformLogicAsync(
                SignInCommand request, CancellationToken cancellationToken)
            {
                var identityUser = await _userManager.FindByEmailAsync(request.Email);
                if (identityUser is null)
                {
                    return ServiceResponseBuilder.Failure<SignInResultDto>(AccountError.LoginUserError);
                }

                var isCredentialsValid = await _userManager.CheckPasswordAsync(identityUser, request.Password);
                if (!isCredentialsValid)
                {
                    return ServiceResponseBuilder.Failure<SignInResultDto>(AccountError.LoginUserError);
                }

                var token = await _tokenGenerator.GenerateAsync(identityUser);
                var result = new SignInResultDto()
                {
                    UserId = Guid.Parse(identityUser.Id),
                    Bearer = token,
                };

                return ServiceResponseBuilder.Success(result);
            }
        }
    }
}
