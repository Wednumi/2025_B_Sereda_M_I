﻿using MediatR;
using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Shared.Dto.Account;
using CutManager.Shared.Helpers;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;

namespace CutManager.Server.Features.Account
{
    public class CreateCustomerCommand : CredentialsDto, IRequest<ServiceResponse>
    {
        public class CreateCustomerCommandHandler : HandlerBase<CreateCustomerCommand>
        {
            private readonly IMediator _mediator;
            private readonly ApplicationDbContext _context;

            public CreateCustomerCommandHandler(IMediator mediator,
                ApplicationDbContext context,
                ILogger<CreateCustomerCommandHandler> logger)
                :base(logger)
            {
                _mediator = mediator;
                _context = context;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(CreateCustomerCommand request,
                CancellationToken cancellationToken)
            {
                var createIdentityUserCommand = new CreateIdentityUserCommand()
                {
                    Email = request.Email,
                    Password = request.Password,
                    Role = Roles.Customer
                };
                var createIdentityResponse = await _mediator.Send(createIdentityUserCommand, cancellationToken);
                if (createIdentityResponse.IsSuccess is false)
                {
                    return createIdentityResponse.MapErrorResult();
                }

                var customer = new Customer()
                {
                    Id = Guid.Parse(createIdentityResponse.Result.IdentityUser.Id),
                    Email = request.Email
                };

                _context.Customers.Add(customer);
                await _context.SaveChangesAsync(cancellationToken);

                return ServiceResponseBuilder.Success();
            }
        }
    }
}
