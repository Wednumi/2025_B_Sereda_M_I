﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Server.Features.Base;
using CutManager.Server.Services.Interfaces;
using CutManager.Shared.Dto.Account;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Shared.Helpers;

namespace CutManager.Server.Features.Account
{
    public class CreateServiceAdminCommand : CredentialsDto, IRequest<ServiceResponse>
    {
        public class CreateServiceAdminCommandHandler : HandlerBase<CreateServiceAdminCommand>
        {
            private readonly IMediator _mediator;
            private readonly ApplicationDbContext _context;

            public CreateServiceAdminCommandHandler(IMediator mediator,
                ApplicationDbContext context,
                ILogger<CreateServiceAdminCommandHandler> logger)
                : base(logger)
            {
                _mediator = mediator;
                _context = context;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(
                CreateServiceAdminCommand request, CancellationToken cancellationToken)
            {
                var createIdentityUserCommand = new CreateIdentityUserCommand()
                {
                    Email = request.Email,
                    Password = request.Password,
                    Role = Roles.ServiceAdmin
                };

                var createIdentityResponse = await _mediator.Send(createIdentityUserCommand, cancellationToken);
                if (!createIdentityResponse.IsSuccess)
                    return createIdentityResponse.MapErrorResult();

                var entity = new ServiceAdmin
                {
                    Id = Guid.Parse(createIdentityResponse.Result.IdentityUser.Id),
                    Email = request.Email
                };

                _context.ServiceAdmins.Add(entity);
                await _context.SaveChangesAsync(cancellationToken);

                return ServiceResponseBuilder.Success();
            }
        }
    }
}
