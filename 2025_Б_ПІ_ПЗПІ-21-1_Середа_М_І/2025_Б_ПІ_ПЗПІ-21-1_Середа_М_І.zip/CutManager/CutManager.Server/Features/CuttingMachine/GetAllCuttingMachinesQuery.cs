﻿using AutoMapper;
using CutManager.Db;
using CutManager.Shared.Dto.CuttingMachine;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CutManager.Server.Features.CuttingMachine
{
    public class GetAllCuttingMachinesQuery : IRequest<ServiceResponse<List<CuttingMachineDto>>>
    {
        public class GetAllCuttingMachinesQueryHandler : IRequestHandler<GetAllCuttingMachinesQuery, ServiceResponse<List<CuttingMachineDto>>>
        {
            private readonly ApplicationDbContext _context;
            private readonly IMapper _mapper;

            public GetAllCuttingMachinesQueryHandler(ApplicationDbContext context, IMapper mapper)
            {
                _context = context;
                _mapper = mapper;
            }

            public async Task<ServiceResponse<List<CuttingMachineDto>>> Handle(GetAllCuttingMachinesQuery request, CancellationToken cancellationToken)
            {
                var machines = await _context.CuttingMachines
                    .Include(cm => cm.CuttingMachineMaterials)
                    .ToListAsync(cancellationToken);

                var result = _mapper.Map<List<CuttingMachineDto>>(machines);
                return ServiceResponseBuilder.Success(result);
            }
        }
    }
}
