﻿using AutoMapper;
using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Shared.Dto.CuttingMachine;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using Microsoft.EntityFrameworkCore;
using MediatR;
using CutManager.Shared.Errors.ServiceErrors;

namespace CutManager.Server.Features.CuttingMachine
{
    public class CreateOrUpdateCuttingMachineCommand : CuttingMachineDto, IRequest<ServiceResponse>
    {
        public class CreateOrUpdateCuttingMachineCommandHandler : HandlerBase<CreateOrUpdateCuttingMachineCommand>
        {
            private readonly ApplicationDbContext _context;
            private readonly IMapper _mapper;

            public CreateOrUpdateCuttingMachineCommandHandler(ApplicationDbContext context, IMapper mapper, ILogger<CreateOrUpdateCuttingMachineCommandHandler> logger)
                : base(logger)
            {
                _context = context;
                _mapper = mapper;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(CreateOrUpdateCuttingMachineCommand request, CancellationToken cancellationToken)
            {
                CutManager.Db.Models.CuttingMachine? machine;

                if (request.Id.HasValue)
                {
                    machine = await _context.CuttingMachines
                        .Include(cm => cm.CuttingMachineMaterials)
                        .FirstOrDefaultAsync(cm => cm.Id == request.Id.Value, cancellationToken);

                    if (machine == null)
                        return ServiceResponseBuilder.Failure(ServerError.NotFound);

                    _mapper.Map(request, machine);
                }
                else
                {
                    machine = _mapper.Map<CutManager.Db.Models.CuttingMachine>(request);
                    _context.CuttingMachines.Add(machine);
                }

                machine.CuttingMachineMaterials = request.SupportedMaterialIds
                    .Select(id => new CuttingMachineMaterial { CuttingMachineId = machine.Id, MaterialId = id })
                    .ToList();

                await _context.SaveChangesAsync(cancellationToken);
                return ServiceResponseBuilder.Success();
            }
        }
    }
}
