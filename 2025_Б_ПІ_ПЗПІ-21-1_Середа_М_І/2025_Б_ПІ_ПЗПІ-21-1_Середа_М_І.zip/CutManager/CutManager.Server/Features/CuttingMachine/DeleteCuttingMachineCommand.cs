﻿using CutManager.Db;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using Microsoft.EntityFrameworkCore;
using MediatR;
using CutManager.Shared.Errors.ServiceErrors;

namespace CutManager.Server.Features.CuttingMachine
{
    public class DeleteCuttingMachineCommand : IRequest<ServiceResponse>
    {
        public Guid Id { get; set; }

        public class DeleteCuttingMachineCommandHandler : HandlerBase<DeleteCuttingMachineCommand>
        {
            private readonly ApplicationDbContext _context;

            public DeleteCuttingMachineCommandHandler(ApplicationDbContext context, ILogger<DeleteCuttingMachineCommandHandler> logger)
                : base(logger)
            {
                _context = context;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(DeleteCuttingMachineCommand request, CancellationToken cancellationToken)
            {
                var machine = await _context.CuttingMachines
                    .Include(cm => cm.CuttingMachineMaterials)
                    .FirstOrDefaultAsync(cm => cm.Id == request.Id, cancellationToken);

                if (machine == null)
                    return ServiceResponseBuilder.Failure(ServerError.NotFound);

                _context.CuttingMachines.Remove(machine);
                await _context.SaveChangesAsync(cancellationToken);

                return ServiceResponseBuilder.Success();
            }
        }
    }
}
