﻿using CutManager.Db.Models;
using CutManager.Db;
using CutManager.Server.Features.Base;
using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.Helpers;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;
using CutManager.Server.Services.Interfaces;

namespace CutManager.Server.Features.Sheets;

public class MarkSheetDoneCommand : IRequest<ServiceResponse>
{
    public Guid SheetId { get; set; }

    public class Handler : HandlerBase<MarkSheetDoneCommand>
    {
        private readonly ApplicationDbContext _context;
        private readonly IOrderStatusService _orderStatusService;

        public Handler(ApplicationDbContext context, ILogger<Handler> logger, IOrderStatusService orderStatusService)
            : base(logger)
        {
            _context = context;
            _orderStatusService = orderStatusService;
        }

        protected override async Task<ServiceResponse> PerformLogicAsync(MarkSheetDoneCommand request, CancellationToken cancellationToken)
        {
            var sheet = await _context.Sheets
                .Include(s => s.OrderPlacements)
                .FirstOrDefaultAsync(s => s.Id == request.SheetId, cancellationToken);

            if (sheet == null)
                return ServiceResponseBuilder.Failure(ServerError.NotFound);

            sheet.IsDone = true;
            sheet.DoneTime = DateTime.UtcNow;

            await _context.SaveChangesAsync(cancellationToken);

            await _orderStatusService.UpdateStatusesAsync(sheet.OrderPlacements, OrderStatus.Done, CancellationToken.None);

            return ServiceResponseBuilder.Success();
        }
    }
}
