﻿using CutManager.Db;
using CutManager.Server.Services.Interfaces;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using MediatR;
using Microsoft.EntityFrameworkCore;
using CutManager.Shared.Errors.ServiceErrors;

namespace CutManager.Server.Features.Sheets
{
    public class UpdateSheetWithPlacementsCommand : IRequest<ServiceResponse>
    {
        public Guid SheetId { get; set; }

        public class Handler : HandlerBase<UpdateSheetWithPlacementsCommand>
        {
            private readonly ApplicationDbContext _context;
            private readonly ISheetDxfAssemblerService _assembler;
            private readonly IFileConverterService _fileConverter;

            public Handler(ApplicationDbContext context,
                           ISheetDxfAssemblerService assembler,
                           IFileConverterService fileConverter,
                           ILogger<Handler> logger)
                : base(logger)
            {
                _context = context;
                _assembler = assembler;
                _fileConverter = fileConverter;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(UpdateSheetWithPlacementsCommand request, CancellationToken cancellationToken)
            {
                var sheet = await _context.Sheets
                    .Include(s => s.OrderPlacements)
                    .FirstOrDefaultAsync(s => s.Id == request.SheetId, cancellationToken);

                if (sheet == null)
                    return ServiceResponseBuilder.Failure(ServerError.NotFound);

                var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
                var baseDxfPath = Path.Combine(uploadsPath, sheet.DxfFilePath);

                _assembler.LoadBaseSheet(baseDxfPath);

                foreach (var placement in sheet.OrderPlacements)
                {
                    var order = await _context.Orders.FirstOrDefaultAsync(o => o.Id == placement.OrderId, cancellationToken);
                    if (order == null) continue;

                    var orderDxfPath = Path.Combine(uploadsPath, order.DxfFilePath);
                    _assembler.InsertOrderDxf(orderDxfPath, placement.TranslateX, placement.TranslateY);
                }

                _assembler.SaveUpdatedSheet(baseDxfPath);

                var svgPath = await _fileConverter.ConvertDxfToSvgAsync(baseDxfPath, cancellationToken);
                sheet.SvgPreviewPath = svgPath;

                await _context.SaveChangesAsync(cancellationToken);
                return ServiceResponseBuilder.Success();
            }
        }
    }
}
