﻿using CutManager.Db.Models;
using CutManager.Db;
using CutManager.Server.Features.Base;
using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.Helpers;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;
using CutManager.Server.Services.Interfaces;

namespace CutManager.Server.Features.Sheets;

public class DeleteSheetCommand : IRequest<ServiceResponse>
{
    public Guid SheetId { get; set; }

    public class Handler : HandlerBase<DeleteSheetCommand>
    {
        private readonly ApplicationDbContext _context;
        private readonly IOrderStatusService _orderStatusService;

        public Handler(ApplicationDbContext context, ILogger<Handler> logger, IOrderStatusService orderStatusService)
            : base(logger)
        {
            _context = context;
            _orderStatusService = orderStatusService;
        }

        protected override async Task<ServiceResponse> PerformLogicAsync(DeleteSheetCommand request, CancellationToken cancellationToken)
        {
            var sheet = await _context.Sheets
                .Include(s => s.OrderPlacements)
                .ThenInclude(p => p.Order)
                .FirstOrDefaultAsync(s => s.Id == request.SheetId, cancellationToken);

            if (sheet == null)
                return ServiceResponseBuilder.Failure(ServerError.NotFound);

            await _orderStatusService.UpdateStatusesAsync(sheet.OrderPlacements, OrderStatus.Created, CancellationToken.None);

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
            var dxfPath = Path.Combine(uploadsPath, sheet.DxfFilePath);
            var svgPath = Path.Combine(uploadsPath, sheet.SvgPreviewPath);

            if (File.Exists(dxfPath)) File.Delete(dxfPath);
            if (File.Exists(svgPath)) File.Delete(svgPath);

            _context.Sheets.Remove(sheet);
            await _context.SaveChangesAsync(CancellationToken.None);

            return ServiceResponseBuilder.Success();
        }
    }
}
