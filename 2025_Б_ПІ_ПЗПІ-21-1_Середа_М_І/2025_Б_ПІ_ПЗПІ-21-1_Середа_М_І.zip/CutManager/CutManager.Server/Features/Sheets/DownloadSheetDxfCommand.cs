﻿using CutManager.Db;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using MediatR;
using Microsoft.EntityFrameworkCore;
using CutManager.Shared.Errors.ServiceErrors;
using Microsoft.AspNetCore.Mvc;
using CutManager.Server.Extensions;
using CutManager.Shared.Helpers;

namespace CutManager.Server.Features.Sheets
{
    public class DownloadSheetDxfCommand : IRequest<ServiceResponse<FileStreamResult>>
    {
        public Guid SheetId { get; set; }

        public class Handler : HandlerBase<DownloadSheetDxfCommand, FileStreamResult>
        {
            private readonly ApplicationDbContext _context;
            private readonly IHttpContextAccessor _httpContext;

            public Handler(ApplicationDbContext context, IHttpContextAccessor httpContext, ILogger<Handler> logger)
                : base(logger)
            {
                _context = context;
                _httpContext = httpContext;
            }

            protected override async Task<ServiceResponse<FileStreamResult>> PerformLogicAsync(
                DownloadSheetDxfCommand request, CancellationToken cancellationToken)
            {
                var sheet = await _context.Sheets
                    .FirstOrDefaultAsync(s => s.Id == request.SheetId, cancellationToken);

                if (sheet == null)
                    return ServiceResponseBuilder.Failure<FileStreamResult>(ServerError.NotFound);

                var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
                var filePath = Path.Combine(uploadsPath, sheet.DxfFilePath);

                if (!File.Exists(filePath))
                    return ServiceResponseBuilder.Failure<FileStreamResult>(ServerError.NotFound);

                var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                var contentType = "application/octet-stream";
                var fileName = Path.GetFileName(sheet.DxfFilePath);

                var result = new FileStreamResult(fileStream, contentType)
                {
                    FileDownloadName = fileName
                };

                return ServiceResponseBuilder.Success(result);
            }
        }
    }
}
