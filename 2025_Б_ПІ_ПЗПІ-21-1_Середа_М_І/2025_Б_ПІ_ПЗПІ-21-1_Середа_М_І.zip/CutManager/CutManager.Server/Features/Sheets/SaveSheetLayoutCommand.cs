﻿using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using MediatR;
using Microsoft.EntityFrameworkCore;
using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.Dto.Sheet;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using CutManager.Shared.Helpers;
using CutManager.Server.Services.Interfaces;

namespace CutManager.Server.Features.Sheets
{
    public class SaveSheetLayoutCommand : SaveSheetLayoutCommandDto, IRequest<ServiceResponse>
    {
        public class Handler : HandlerBase<SaveSheetLayoutCommand>
        {
            private readonly ApplicationDbContext _context;
            private readonly IMediator _mediator;
            private readonly IOrderStatusService _orderStatusService;

            public Handler(ApplicationDbContext context, ILogger<Handler> logger, IMediator mediator, IOrderStatusService orderStatusService)
                : base(logger)
            {
                _context = context;
                _mediator = mediator;
                _orderStatusService = orderStatusService;
            }

            protected override async Task<ServiceResponse> PerformLogicAsync(SaveSheetLayoutCommand request, CancellationToken cancellationToken)
            {
                var sheet = await _context.Sheets
                    .Include(s => s.OrderPlacements)
                    .FirstOrDefaultAsync(s => s.Id == request.SheetId, cancellationToken);

                if (sheet == null)
                    return ServiceResponseBuilder.Failure(ServerError.NotFound);

                sheet.OrderPlacements.Clear();

                foreach (var placement in request.Placements)
                {
                    sheet.OrderPlacements.Add(new SheetOrderPlacement
                    {
                        OrderId = placement.OrderId,
                        ModelNumber = placement.ModelNumber,
                        TranslateX = placement.TranslateX,
                        TranslateY = placement.TranslateY
                    });
                }

                await _context.SaveChangesAsync(cancellationToken);

                await _orderStatusService.UpdateStatusesAsync(sheet.OrderPlacements, OrderStatus.Processing, CancellationToken.None);

                var updateResponse = await _mediator.Send(new UpdateSheetWithPlacementsCommand
                {
                    SheetId = request.SheetId
                }, CancellationToken.None);

                return ServiceResponseBuilder.Success();
            }
        }
    }
}
