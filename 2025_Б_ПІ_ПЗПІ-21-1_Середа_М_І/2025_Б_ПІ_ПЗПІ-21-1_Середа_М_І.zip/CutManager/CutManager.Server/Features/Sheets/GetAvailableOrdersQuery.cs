﻿using CutManager.Db;
using CutManager.Shared.Dto.Sheet;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using MediatR;
using Microsoft.EntityFrameworkCore;
using CutManager.Shared.Helpers;

namespace CutManager.Server.Features.Sheets
{
    public class GetAvailableOrdersQuery : IRequest<ServiceResponse<List<AvailableOrderDto>>>
    {
        public class Handler : HandlerBase<GetAvailableOrdersQuery, List<AvailableOrderDto>>
        {
            private readonly ApplicationDbContext _context;

            public Handler(ApplicationDbContext context, ILogger<Handler> logger)
                : base(logger)
            {
                _context = context;
            }

            protected override async Task<ServiceResponse<List<AvailableOrderDto>>> PerformLogicAsync(GetAvailableOrdersQuery request, CancellationToken cancellationToken)
            {
                var orders = await _context.Orders
                    .Where(o => o.CurrentStatus == OrderStatus.Created)
                    .Include(o => o.Material)
                    .Select(o => new AvailableOrderDto
                    {
                        Id = o.Id,
                        MaterialId = o.MaterialId,
                        MaterialName = o.Material.Name,
                        Thickness = o.Thickness,
                        Quantity = o.Quantity,
                        SvgPreviewPath = o.SvgPreviewPath
                    })
                    .ToListAsync(cancellationToken);

                return ServiceResponseBuilder.Success(orders);
            }
        }
    }
}
