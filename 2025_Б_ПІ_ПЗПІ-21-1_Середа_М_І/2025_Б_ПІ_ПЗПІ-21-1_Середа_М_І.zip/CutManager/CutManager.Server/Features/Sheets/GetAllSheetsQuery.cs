﻿using CutManager.Db;
using CutManager.Server.Features.Base;
using CutManager.Shared.Dto.Sheet;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CutManager.Server.Features.Sheets;

public class GetAllSheetsQuery : IRequest<ServiceResponse<List<SheetDto>>>
{
    public class Handler : HandlerBase<GetAllSheetsQuery, List<SheetDto>>
    {
        private readonly ApplicationDbContext _context;

        public Handler(ApplicationDbContext context, ILogger<Handler> logger)
            : base(logger) 
        {
            _context = context;
        }

        protected override async Task<ServiceResponse<List<SheetDto>>> PerformLogicAsync(GetAllSheetsQuery request, CancellationToken cancellationToken)
        {
            var result = await _context.Sheets
                .Include(s => s.Material)
                .Include(s => s.CuttingMachine)
                .Select(s => new SheetDto
                {
                    Id = s.Id,
                    MachineName = s.CuttingMachine.Name,
                    MaterialName = s.Material.Name,
                    Thickness = s.Thickness,
                    IsDone = s.IsDone,
                    DoneTime = s.DoneTime,
                }).ToListAsync(cancellationToken);

            return ServiceResponseBuilder.Success(result);
        }
    }
}
