﻿using AutoMapper;
using CutManager.Db;
using CutManager.Db.Models;
using CutManager.Shared.ServiceResponseHandling;
using CutManager.Server.Features.Base;
using CutManager.Server.Services.Interfaces;
using MediatR;
using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.Dto.Sheet;
using BlueprintsManager;

namespace CutManager.Server.Features.Sheets;

public class CreateSheetCommand : CreateSheetCommandDto, IRequest<ServiceResponse<Guid>>
{
    public class Handler : HandlerBase<CreateSheetCommand, Guid>
    {
        private readonly ApplicationDbContext _context;
        private readonly IFileConverterService _fileConverter;

        public Handler(ApplicationDbContext context, ILogger<Handler> logger, IFileConverterService fileConverter)
            : base(logger)
        {
            _context = context;
            _fileConverter = fileConverter;
        }

        protected override async Task<ServiceResponse<Guid>> PerformLogicAsync(CreateSheetCommand request, CancellationToken cancellationToken)
        {
            var machine = await _context.CuttingMachines.FindAsync(new object[] { request.CuttingMachineId }, cancellationToken);
            if (machine == null)
                return ServiceResponseBuilder.Failure<Guid>(ServerError.NotFound);

            var sheet = new Sheet
            {
                CuttingMachineId = machine.Id,
                MaterialId = request.MaterialId,
                Thickness = request.Thickness,
                Width = machine.MaxWidth,
                Height = machine.MaxHeight,
            };

            _context.Sheets.Add(sheet);
            await _context.SaveChangesAsync(cancellationToken);

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "app_data", "uploads");
            Directory.CreateDirectory(uploadsPath);

            var dxfFileName = $"{sheet.Id}.dxf";
            var dxfFilePath = Path.Combine(uploadsPath, dxfFileName);

            var svgFileName = $"{sheet.Id}.svg";

            DxfSheetFactory.CreateSheet(machine.MaxWidth, machine.MaxHeight, dxfFilePath);

            await _fileConverter.ConvertDxfToSvgAsync(dxfFilePath, cancellationToken);

            sheet.DxfFilePath = dxfFileName;
            sheet.SvgPreviewPath = svgFileName;

            await _context.SaveChangesAsync(cancellationToken);

            return ServiceResponseBuilder.Success(sheet.Id);
        }
    }
}
