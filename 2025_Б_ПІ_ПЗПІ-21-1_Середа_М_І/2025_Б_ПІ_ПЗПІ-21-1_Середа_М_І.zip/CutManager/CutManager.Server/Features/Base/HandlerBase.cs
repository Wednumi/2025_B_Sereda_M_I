﻿using CutManager.Shared.Errors.ServiceErrors;
using CutManager.Shared.ServiceResponseHandling;
using MediatR;

namespace CutManager.Server.Features.Base
{
    public abstract class HandlerBase<TRequest, TResponse> : IRequestHandler<TRequest, ServiceResponse<TResponse>> where TRequest : IRequest<ServiceResponse<TResponse>>
    {
        protected readonly ILogger _logger;

        protected HandlerBase(ILogger logger)
        {
            _logger = logger;
        }

        public async Task<ServiceResponse<TResponse>> Handle(TRequest request, CancellationToken cancellationToken)
        {
            try
            {
                return await PerformLogicAsync(request, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Unexpected error in: {typeof(TRequest)} handler");
                return ServiceResponseBuilder.Failure<TResponse>(ServerError.SomethingWentWrong);
            }
        }

        protected abstract Task<ServiceResponse<TResponse>> PerformLogicAsync(
            TRequest request,
            CancellationToken cancellationToken);
    }

    public abstract class HandlerBase<TRequest> : IRequestHandler<TRequest, ServiceResponse> where TRequest : IRequest<ServiceResponse>
    {
        protected readonly ILogger _logger;

        protected HandlerBase(ILogger logger)
        {
            _logger = logger;
        }

        public async Task<ServiceResponse> Handle(TRequest request, CancellationToken cancellationToken)
        {
            try
            {
                return await PerformLogicAsync(request, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Unexpected error in: {typeof(TRequest)} handler");
                return ServiceResponseBuilder.Failure(ServerError.SomethingWentWrong);
            }
        }

        protected abstract Task<ServiceResponse> PerformLogicAsync(
            TRequest request,
            CancellationToken cancellationToken);
    }
}
