﻿using Microsoft.AspNetCore.Identity;

namespace CutManager.Server.Models.Account
{
    public class CreateIdentityUserResult
    {
        public IdentityUser IdentityUser { get; set; }
    }
}
