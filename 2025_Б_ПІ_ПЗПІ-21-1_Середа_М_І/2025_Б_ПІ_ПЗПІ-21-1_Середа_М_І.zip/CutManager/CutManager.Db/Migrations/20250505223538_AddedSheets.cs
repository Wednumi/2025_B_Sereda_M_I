﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CutManager.Db.Migrations
{
    /// <inheritdoc />
    public partial class AddedSheets : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Sheets",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    CuttingMachineId = table.Column<Guid>(type: "uuid", nullable: false),
                    MaterialId = table.Column<Guid>(type: "uuid", nullable: false),
                    Thickness = table.Column<float>(type: "real", nullable: false),
                    Width = table.Column<float>(type: "real", nullable: false),
                    Height = table.Column<float>(type: "real", nullable: false),
                    DxfFilePath = table.Column<string>(type: "text", nullable: false),
                    SvgPreviewPath = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sheets", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sheets_CuttingMachines_CuttingMachineId",
                        column: x => x.CuttingMachineId,
                        principalTable: "CuttingMachines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Sheets_Materials_MaterialId",
                        column: x => x.MaterialId,
                        principalTable: "Materials",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SheetOrderPlacements",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    SheetId = table.Column<Guid>(type: "uuid", nullable: false),
                    OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                    ModelNumber = table.Column<int>(type: "integer", nullable: false),
                    TranslateX = table.Column<float>(type: "real", nullable: false),
                    TranslateY = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SheetOrderPlacements", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SheetOrderPlacements_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SheetOrderPlacements_Sheets_SheetId",
                        column: x => x.SheetId,
                        principalTable: "Sheets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SheetOrderPlacements_OrderId",
                table: "SheetOrderPlacements",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_SheetOrderPlacements_SheetId",
                table: "SheetOrderPlacements",
                column: "SheetId");

            migrationBuilder.CreateIndex(
                name: "IX_Sheets_CuttingMachineId",
                table: "Sheets",
                column: "CuttingMachineId");

            migrationBuilder.CreateIndex(
                name: "IX_Sheets_MaterialId",
                table: "Sheets",
                column: "MaterialId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SheetOrderPlacements");

            migrationBuilder.DropTable(
                name: "Sheets");
        }
    }
}
