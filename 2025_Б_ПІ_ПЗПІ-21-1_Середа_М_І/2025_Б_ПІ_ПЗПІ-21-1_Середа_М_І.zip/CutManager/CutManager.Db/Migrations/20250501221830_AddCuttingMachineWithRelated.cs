﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CutManager.Db.Migrations
{
    /// <inheritdoc />
    public partial class AddCuttingMachineWithRelated : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CuttingMachines",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "text", nullable: false),
                    MaxWidth = table.Column<decimal>(type: "numeric", nullable: false),
                    MaxHeight = table.Column<decimal>(type: "numeric", nullable: false),
                    Description = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CuttingMachines", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Materials",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "text", nullable: false),
                    Type = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Materials", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ServiceAdmins",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true),
                    Phone = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ServiceAdmins", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CuttingMachineMaterials",
                columns: table => new
                {
                    CuttingMachineId = table.Column<Guid>(type: "uuid", nullable: false),
                    MaterialId = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CuttingMachineMaterials", x => new { x.CuttingMachineId, x.MaterialId });
                    table.ForeignKey(
                        name: "FK_CuttingMachineMaterials_CuttingMachines_CuttingMachineId",
                        column: x => x.CuttingMachineId,
                        principalTable: "CuttingMachines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CuttingMachineMaterials_Materials_MaterialId",
                        column: x => x.MaterialId,
                        principalTable: "Materials",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MaterialThicknesses",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    MaterialId = table.Column<Guid>(type: "uuid", nullable: false),
                    Thickness = table.Column<decimal>(type: "numeric", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaterialThicknesses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MaterialThicknesses_Materials_MaterialId",
                        column: x => x.MaterialId,
                        principalTable: "Materials",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_CuttingMachineMaterials_MaterialId",
                table: "CuttingMachineMaterials",
                column: "MaterialId");

            migrationBuilder.CreateIndex(
                name: "IX_MaterialThicknesses_MaterialId",
                table: "MaterialThicknesses",
                column: "MaterialId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CuttingMachineMaterials");

            migrationBuilder.DropTable(
                name: "MaterialThicknesses");

            migrationBuilder.DropTable(
                name: "ServiceAdmins");

            migrationBuilder.DropTable(
                name: "CuttingMachines");

            migrationBuilder.DropTable(
                name: "Materials");
        }
    }
}
