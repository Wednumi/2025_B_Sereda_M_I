﻿namespace CutManager.Db.Models
{
    public class MaterialThickness : Entity
    {
        public Guid MaterialId { get; set; }
        public Material Material { get; set; } = null!;
        public float Thickness { get; set; }
    }
}
