﻿using CutManager.Shared.Helpers;

namespace CutManager.Db.Models
{
    public class OrderStatusHistory : Entity
    {
        public Guid OrderId { get; set; }
        public Order Order { get; set; } = null!;

        public OrderStatus Status { get; set; }
        public DateTime ChangedAt { get; set; }
    }

}
