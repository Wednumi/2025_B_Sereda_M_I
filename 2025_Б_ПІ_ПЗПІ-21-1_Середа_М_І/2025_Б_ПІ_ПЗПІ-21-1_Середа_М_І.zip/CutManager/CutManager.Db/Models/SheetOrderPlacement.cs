﻿namespace CutManager.Db.Models
{
    public class SheetOrderPlacement : Entity
    {
        public Guid SheetId { get; set; }
        public Sheet Sheet { get; set; } = null!;

        public Guid OrderId { get; set; }
        public Order Order { get; set; } = null!;

        public int ModelNumber { get; set; }

        public float TranslateX { get; set; } 
        public float TranslateY { get; set; } 
    }

}
