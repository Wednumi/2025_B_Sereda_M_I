namespace CutManager.Db.Models
{
    public class Material : Entity
    {
        public string Name { get; set; } = string.Empty;
        public string? Type { get; set; }
        public ICollection<MaterialThickness> Thicknesses { get; set; } = new List<MaterialThickness>();
        public ICollection<CuttingMachineMaterial> CuttingMachineMaterials { get; set; } = new List<CuttingMachineMaterial>();
    }
}
