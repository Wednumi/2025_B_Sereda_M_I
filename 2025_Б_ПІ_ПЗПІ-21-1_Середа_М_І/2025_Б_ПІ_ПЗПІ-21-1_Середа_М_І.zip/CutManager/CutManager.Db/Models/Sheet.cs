﻿namespace CutManager.Db.Models
{
    public class Sheet : Entity
    {
        public Guid CuttingMachineId { get; set; }
        public CuttingMachine CuttingMachine { get; set; } = null!;

        public Guid MaterialId { get; set; }
        public Material Material { get; set; } = null!;

        public float Thickness { get; set; }

        public float Width { get; set; }
        public float Height { get; set; } 

        public string DxfFilePath { get; set; } = string.Empty;
        public string SvgPreviewPath { get; set; } = string.Empty;

        public bool IsDone { get; set; }
        public DateTime? DoneTime { get; set; }

        public ICollection<SheetOrderPlacement> OrderPlacements { get; set; } = new List<SheetOrderPlacement>();
    }

}
