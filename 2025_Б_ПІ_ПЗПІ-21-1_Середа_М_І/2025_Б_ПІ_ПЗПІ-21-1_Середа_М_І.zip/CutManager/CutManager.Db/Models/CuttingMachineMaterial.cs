﻿namespace CutManager.Db.Models
{
    public class CuttingMachineMaterial
    {
        public Guid CuttingMachineId { get; set; }
        public CuttingMachine CuttingMachine { get; set; } = null!;

        public Guid MaterialId { get; set; }
        public Material Material { get; set; } = null!;
    }
}
