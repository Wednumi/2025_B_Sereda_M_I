﻿using CutManager.Shared.Helpers;

namespace CutManager.Db.Models
{
    public class Order : Entity
    {
        public Guid CustomerId { get; set; }
        public Customer Customer { get; set; } = null!;

        public Guid MaterialId { get; set; }
        public Material Material { get; set; } = null!;

        public float Thickness { get; set; }
        public int Quantity { get; set; }

        public string DxfFilePath { get; set; } = string.Empty;
        public string SvgPreviewPath { get; set; } = string.Empty;

        public OrderStatus CurrentStatus { get; set; }

        public DateTime CreatedAt { get; set; }

        public ICollection<OrderStatusHistory> StatusHistory { get; set; } = new List<OrderStatusHistory>();
    }

}
