﻿namespace CutManager.Db.Models
{
    public class CuttingMachine : Entity
    {
        public string Name { get; set; } = string.Empty;
        public float MaxWidth { get; set; }
        public float MaxHeight { get; set; }
        public string? Description { get; set; }
        public ICollection<CuttingMachineMaterial> CuttingMachineMaterials { get; set; } = new List<CuttingMachineMaterial>();
    }
}
