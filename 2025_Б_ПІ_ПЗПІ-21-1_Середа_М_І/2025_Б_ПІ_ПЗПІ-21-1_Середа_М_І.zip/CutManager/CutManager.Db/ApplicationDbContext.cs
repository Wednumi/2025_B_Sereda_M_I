﻿using CutManager.Db.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CutManager.Db
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUser>
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<ServiceAdmin> ServiceAdmins { get; set; }
        public DbSet<Material> Materials { get; set; }
        public DbSet<MaterialThickness> MaterialThicknesses { get; set; }
        public DbSet<CuttingMachine> CuttingMachines { get; set; }
        public DbSet<CuttingMachineMaterial> CuttingMachineMaterials { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderStatusHistory> OrderStatusHistories { get; set; }
        public DbSet<Sheet> Sheets { get; set; }
        public DbSet<SheetOrderPlacement> SheetOrderPlacements { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<CuttingMachineMaterial>()
                .HasKey(cm => new { cm.CuttingMachineId, cm.MaterialId });

            modelBuilder.Entity<CuttingMachineMaterial>()
                .HasOne(cm => cm.CuttingMachine)
                .WithMany(c => c.CuttingMachineMaterials)
                .HasForeignKey(cm => cm.CuttingMachineId);

            modelBuilder.Entity<CuttingMachineMaterial>()
                .HasOne(cm => cm.Material)
                .WithMany(m => m.CuttingMachineMaterials)
                .HasForeignKey(cm => cm.MaterialId);

            modelBuilder.Entity<MaterialThickness>()
                .HasOne(mt => mt.Material)
                .WithMany(m => m.Thicknesses)
                .HasForeignKey(mt => mt.MaterialId);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.Customer)
                .WithMany()
                .HasForeignKey(o => o.CustomerId);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.Material)
                .WithMany()
                .HasForeignKey(o => o.MaterialId);

            modelBuilder.Entity<OrderStatusHistory>()
                .HasOne(sh => sh.Order)
                .WithMany(o => o.StatusHistory)
                .HasForeignKey(sh => sh.OrderId);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.Customer)
                .WithMany(c => c.Orders)
                .HasForeignKey(o => o.CustomerId);

            modelBuilder.Entity<Sheet>()
                .HasOne(s => s.CuttingMachine)
                .WithMany()
                .HasForeignKey(s => s.CuttingMachineId);

            modelBuilder.Entity<Sheet>()
                .HasOne(s => s.Material)
                .WithMany()
                .HasForeignKey(s => s.MaterialId);

            modelBuilder.Entity<SheetOrderPlacement>()
                .HasOne(p => p.Sheet)
                .WithMany(s => s.OrderPlacements)
                .HasForeignKey(p => p.SheetId);

            modelBuilder.Entity<SheetOrderPlacement>()
                .HasOne(p => p.Order)
                .WithMany()
                .HasForeignKey(p => p.OrderId);
        }
    }
}
