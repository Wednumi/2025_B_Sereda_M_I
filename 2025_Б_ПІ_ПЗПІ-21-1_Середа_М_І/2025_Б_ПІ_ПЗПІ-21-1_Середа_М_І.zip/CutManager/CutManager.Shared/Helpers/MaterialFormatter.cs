using CutManager.Shared.Dto.Material;

namespace CutManager.Shared.Helpers
{
    public static class MaterialFormatter
    {
        public static string GetMaterialString(MaterialDto materialDto)
        {
            return $"{materialDto.Name} {GetThicknessesString(materialDto)}";
        }

        public static string GetThicknessesString(MaterialDto materialDto)
        {
            return string.Join(", ", materialDto.Thicknesses);
        }
    }
}
