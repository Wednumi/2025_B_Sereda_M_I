﻿namespace CutManager.Shared.Helpers
{
    public static class Roles
    {
        public const string Customer = "Customer";
        public const string ServiceAdmin = "ServiceAdmin";
        public const string ServiceEmployee = "ServiceEmployee";
        public const string Administrator = "Administrator";
    }
}
