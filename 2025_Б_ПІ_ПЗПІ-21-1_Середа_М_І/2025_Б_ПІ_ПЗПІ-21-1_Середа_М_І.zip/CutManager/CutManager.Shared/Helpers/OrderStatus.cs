﻿namespace CutManager.Shared.Helpers
{
    public enum OrderStatus
    {
        Created,
        Processing,
        Done
    }
}
