﻿using CutManager.Shared.Errors.Base;

namespace CutManager.Shared.Errors.ServiceErrors
{
    public class OrderError : ServiceError
    {
        public OrderError(string header, string message, int code)
        {
            Header = header;
            ErrorMessage = message;
            Code = code;
        }

        public static OrderError InvalidMaterialThickness =>
            new("Invalid thickness", "The specified thickness is not available for the selected material", 1);

        public static OrderError MaterialNotSupportedByMachine =>
            new("Material not supported", "The selected material is not supported", 2);
    }

}
