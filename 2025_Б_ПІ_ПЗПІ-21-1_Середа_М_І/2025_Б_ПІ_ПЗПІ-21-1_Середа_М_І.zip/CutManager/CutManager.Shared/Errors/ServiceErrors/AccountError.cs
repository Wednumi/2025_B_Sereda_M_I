﻿using CutManager.Shared.Errors.Base;

namespace CutManager.Shared.Errors.ServiceErrors
{
    public class AccountError : ServiceError
    {
        public AccountError(string header, string message, int code)
        {
            Header = header;
            ErrorMessage = message;
            Code = code;
        }

        public static AccountError LoginUserError =>
            new AccountError("Login error", "Email or password is not valid", 1);
    }
}
