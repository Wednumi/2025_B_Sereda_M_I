﻿using CutManager.Shared.Errors.Base;

namespace CutManager.Shared.Errors.ServiceErrors
{
    public class ServerError : ServiceError
    {
        public ServerError(string header, string message, int code)
        {
            Header = header;
            ErrorMessage = message;
            Code = code;
        }

        private const string ErrorString = "Something went wrong";

        public static ServerError SomethingWentWrong => new(ErrorString, ErrorString, 1);
        public static ServerError NotFound => new("Not found", ErrorString, 2);
    }
}
