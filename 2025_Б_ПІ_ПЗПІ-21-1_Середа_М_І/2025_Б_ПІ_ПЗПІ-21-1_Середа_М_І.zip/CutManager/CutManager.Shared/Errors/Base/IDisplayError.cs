﻿namespace CutManager.Shared.Errors.Base
{
    public interface IDisplayError
    {
        public string ErrorMessage { get; set; }
    }
}
