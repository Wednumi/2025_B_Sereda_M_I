﻿namespace CutManager.Shared.Dto.Account
{
    public class SignInCommandDto : CredentialsDto
    {
    }
}
