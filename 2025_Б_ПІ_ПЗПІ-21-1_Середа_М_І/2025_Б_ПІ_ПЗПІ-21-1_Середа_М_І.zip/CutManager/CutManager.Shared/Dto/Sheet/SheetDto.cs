namespace CutManager.Shared.Dto.Sheet
{
    public class SheetDto
    {
        public Guid Id { get; set; }
        public string MachineName { get; set; } = string.Empty;
        public string MaterialName { get; set; } = string.Empty;
        public float Thickness { get; set; }
        public bool IsDone { get; set; }
        public DateTime? DoneTime { get; set; }
    }
}