﻿namespace CutManager.Shared.Dto.Sheet
{
    public class CreateSheetCommandDto
    {
        public Guid CuttingMachineId { get; set; }
        public Guid MaterialId { get; set; }
        public float Thickness { get; set; }
    }
}
