﻿namespace CutManager.Shared.Dto.Sheet
{
    public class SaveSheetLayoutCommandDto
    {
        public Guid SheetId { get; set; }
        public List<PlacementDto> Placements { get; set; } = new();
    }
}
