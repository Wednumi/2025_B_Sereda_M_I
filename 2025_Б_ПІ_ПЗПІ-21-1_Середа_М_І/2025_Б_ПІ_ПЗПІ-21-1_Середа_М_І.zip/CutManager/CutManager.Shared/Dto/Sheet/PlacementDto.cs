﻿namespace CutManager.Shared.Dto.Sheet
{
    public class PlacementDto
    {
        public Guid OrderId { get; set; }
        public int ModelNumber { get; set; }
        public float TranslateX { get; set; }
        public float TranslateY { get; set; }
    }
}
