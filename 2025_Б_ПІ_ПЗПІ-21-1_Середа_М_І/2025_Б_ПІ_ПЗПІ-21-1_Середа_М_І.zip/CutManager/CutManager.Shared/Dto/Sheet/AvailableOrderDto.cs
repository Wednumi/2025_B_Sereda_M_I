﻿namespace CutManager.Shared.Dto.Sheet
{
    public class AvailableOrderDto
    {
        public Guid Id { get; set; }
        public Guid MaterialId { get; set; }
        public string MaterialName { get; set; } = string.Empty;
        public float Thickness { get; set; }
        public int Quantity { get; set; }
        public string SvgPreviewPath { get; set; } = string.Empty;
    }
}
