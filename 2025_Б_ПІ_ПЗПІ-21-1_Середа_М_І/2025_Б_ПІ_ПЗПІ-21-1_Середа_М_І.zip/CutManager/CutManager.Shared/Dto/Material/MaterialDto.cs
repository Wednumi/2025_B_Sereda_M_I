﻿namespace CutManager.Shared.Dto.Material
{
    public class MaterialDto
    {
        public Guid? Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Type { get; set; }
        public List<float> Thicknesses { get; set; } = new();
    }
}
