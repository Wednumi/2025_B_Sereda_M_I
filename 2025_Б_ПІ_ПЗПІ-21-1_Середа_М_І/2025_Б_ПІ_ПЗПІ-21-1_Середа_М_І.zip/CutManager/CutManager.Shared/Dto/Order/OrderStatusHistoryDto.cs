﻿namespace CutManager.Shared.Dto.Order
{
    public class OrderStatusHistoryDto
    {
        public string Status { get; set; } = string.Empty;
        public DateTime ChangedAt { get; set; }
    }
}
