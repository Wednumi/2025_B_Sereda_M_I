﻿using Microsoft.AspNetCore.Http;

namespace CutManager.Shared.Dto.Order
{
    public class CreateOrderFormDto
    {
        public Guid MaterialId { get; set; }
        public string? Thickness { get; set; }
        public int Quantity { get; set; }
        public IFormFile File { get; set; } = null!;
    }

}
