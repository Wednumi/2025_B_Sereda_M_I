﻿namespace CutManager.Shared.Dto.Order
{
    public class CreateOrderCommandDto
    {
        public Guid MaterialId { get; set; }
        public float Thickness { get; set; }
        public int Quantity { get; set; }
        public string DxfFileName { get; set; } = string.Empty;
    }
}
