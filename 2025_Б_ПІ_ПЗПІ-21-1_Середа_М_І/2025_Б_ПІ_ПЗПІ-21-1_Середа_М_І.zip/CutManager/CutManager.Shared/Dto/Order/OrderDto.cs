﻿namespace CutManager.Shared.Dto.Order
{
    public class OrderDto
    {
        public Guid Id { get; set; }
        public string MaterialName { get; set; } = string.Empty;
        public float Thickness { get; set; }
        public int Quantity { get; set; }
        public string CurrentStatus { get; set; } = string.Empty;
        public List<OrderStatusHistoryDto> StatusHistory { get; set; } = new();
    }
}
