﻿using CutManager.Shared.Dto.CuttingMachine;
using FluentValidation;

namespace CutManager.Shared.Validators.Admin
{
    public class CreateOrUpdateCuttingMachineValidator : AbstractValidator<CuttingMachineDto>
    {
        public CreateOrUpdateCuttingMachineValidator()
        {
            RuleFor(c => c.Name)
                .NotEmpty();

            RuleFor(c => c.MaxWidth)
                .NotEmpty()
                .GreaterThan(0);

            RuleFor(c => c.MaxHeight)
                .NotEmpty()
                .GreaterThan(0);

            RuleFor(c => c.SupportedMaterialIds)
               .NotEmpty();
        }
    }
}
