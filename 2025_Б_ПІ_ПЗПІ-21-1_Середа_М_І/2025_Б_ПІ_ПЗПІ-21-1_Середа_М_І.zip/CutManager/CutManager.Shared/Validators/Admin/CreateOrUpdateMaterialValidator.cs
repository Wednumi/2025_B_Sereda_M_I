﻿using CutManager.Shared.Dto.Material;
using FluentValidation;

namespace CutManager.Shared.Validators.Admin
{
    public class CreateOrUpdateMaterialValidator : AbstractValidator<MaterialDto>
    {
        public CreateOrUpdateMaterialValidator()
        {
            RuleFor(c => c.Name)
                .NotEmpty();

            RuleFor(c => c.Thicknesses)
                .NotEmpty();
        }
    }
}
