﻿using CutManager.Shared.Dto.Order;
using FluentValidation;

namespace CutManager.Shared.Validators.Customer
{
    public class CreateOrderValidator : AbstractValidator<CreateOrderCommandDto>
    {
        public CreateOrderValidator()
        {
            RuleFor(c => c.MaterialId)
                .NotEmpty();

            RuleFor(c => c.Thickness)
                .NotEmpty()
                .GreaterThan(0);

            RuleFor(c => c.Quantity)
                .NotEmpty()
                .GreaterThan(0);
        }
    }
}
