﻿using FluentValidation;
using CutManager.Shared.Dto.Account;

namespace CutManager.Shared.Validators.Account
{
    public class CreateIdentityUserCommandValidator : AbstractValidator<CredentialsDto>
    {
        public CreateIdentityUserCommandValidator()
        {
            RuleFor(c => c.Email)
                .NotEmpty()
                .EmailAddress();

            RuleFor(c => c.Password)
                .NotEmpty()
                .MinimumLength(8);
        }
    }
}